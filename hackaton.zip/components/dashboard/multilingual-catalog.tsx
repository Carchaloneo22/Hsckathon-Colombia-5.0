"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Globe, Package, DollarSign, Scale, Leaf } from "lucide-react"

type Language = "es" | "en" | "fr"

interface ProductTranslation {
  name: string
  description: string
  characteristics: string[]
  origin: string
  certification: string
}

interface Product {
  id: string
  image: string
  price: number
  weight: string
  organic: boolean
  translations: Record<Language, ProductTranslation>
}

const languages: { code: Language; label: string; flag: string }[] = [
  { code: "es", label: "Español", flag: "🇪🇸" },
  { code: "en", label: "English", flag: "🇺🇸" },
  { code: "fr", label: "Français", flag: "🇫🇷" },
]

interface MultilingualCatalogProps {
  products: Product[]
}

export function MultilingualCatalog({ products }: MultilingualCatalogProps) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>("es")

  const getLanguageLabels = (lang: Language) => {
    const labels = {
      es: { characteristics: "Características", origin: "Origen", certification: "Certificación", weight: "Peso" },
      en: { characteristics: "Characteristics", origin: "Origin", certification: "Certification", weight: "Weight" },
      fr: { characteristics: "Caractéristiques", origin: "Origine", certification: "Certification", weight: "Poids" },
    }
    return labels[lang]
  }

  const labels = getLanguageLabels(currentLanguage)

  return (
    <Card className="border-border/50 shadow-lg">
      <CardHeader className="border-b border-border/30">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Globe className="w-6 h-6 text-primary" />
              Perfil Multilingüe
            </CardTitle>
            <CardDescription className="text-lg text-muted-foreground mt-1">
              Catálogo de productos en múltiples idiomas
            </CardDescription>
          </div>
          
          {/* Language Selector */}
          <div className="flex gap-2">
            {languages.map((lang) => (
              <Button
                key={lang.code}
                variant={currentLanguage === lang.code ? "default" : "outline"}
                onClick={() => setCurrentLanguage(lang.code)}
                className={`px-4 py-2 text-base font-medium transition-all ${
                  currentLanguage === lang.code
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "hover:bg-primary/10"
                }`}
              >
                <span className="mr-2 text-lg">{lang.flag}</span>
                {lang.label}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid gap-6">
          {products.map((product) => {
            const translation = product.translations[currentLanguage]
            return (
              <div
                key={product.id}
                className="flex flex-col md:flex-row gap-6 p-5 rounded-xl border border-border/50 bg-card hover:shadow-md transition-shadow"
              >
                {/* Product Image */}
                <div className="w-full md:w-48 h-48 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                    <Package className="w-16 h-16 text-primary/50" />
                  </div>
                </div>

                {/* Product Details */}
                <div className="flex-1 space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-2xl font-bold text-foreground">
                        {translation.name}
                      </h3>
                      <p className="text-muted-foreground mt-1 text-lg leading-relaxed">
                        {translation.description}
                      </p>
                    </div>
                    {product.organic && (
                      <Badge className="bg-primary/10 text-primary border border-primary/30 flex items-center gap-1">
                        <Leaf className="w-3.5 h-3.5" />
                        Organic
                      </Badge>
                    )}
                  </div>

                  {/* Characteristics */}
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground mb-2">
                      {labels.characteristics}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {translation.characteristics.map((char, idx) => (
                        <Badge
                          key={idx}
                          variant="secondary"
                          className="text-sm px-3 py-1"
                        >
                          {char}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Meta Information */}
                  <div className="flex flex-wrap items-center gap-6 pt-2 border-t border-border/30">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-primary" />
                      <span className="text-xl font-bold text-foreground">
                        ${product.price.toFixed(2)} USD
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Scale className="w-4 h-4" />
                      <span>{labels.weight}: {product.weight}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Globe className="w-4 h-4" />
                      <span>{labels.origin}: {translation.origin}</span>
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
