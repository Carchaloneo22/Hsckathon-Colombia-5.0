"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { QrCode, MapPin, Building2, Calendar, Shield } from "lucide-react"

interface ProductOrigin {
  productName: string
  productType: string
  producerName: string
  location: string
  coordinates: { lat: number; lng: number }
  certificateId: string
  issueDate: string
  expiryDate: string
  verified: boolean
}

interface TraceabilityCertificateProps {
  product: ProductOrigin
}

export function TraceabilityCertificate({ product }: TraceabilityCertificateProps) {
  return (
    <Card className="border-border/50 shadow-lg overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-primary/10 to-accent/10 border-b border-border/30">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-2xl font-bold text-foreground flex items-center gap-2">
              <Shield className="w-6 h-6 text-primary" />
              Certificado Digital
            </CardTitle>
            <CardDescription className="text-lg text-muted-foreground mt-1">
              Trazabilidad verificada del producto
            </CardDescription>
          </div>
          {product.verified && (
            <Badge className="bg-primary text-primary-foreground text-sm px-3 py-1">
              Verificado
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid md:grid-cols-2 gap-8">
          {/* QR Code Section */}
          <div className="flex flex-col items-center gap-4">
            <div className="bg-white p-4 rounded-xl shadow-md border border-border/30">
              <div className="w-44 h-44 bg-gradient-to-br from-foreground to-foreground/80 rounded-lg flex items-center justify-center relative overflow-hidden">
                {/* Simulated QR Code Pattern */}
                <div className="absolute inset-2 grid grid-cols-7 gap-1">
                  {Array.from({ length: 49 }).map((_, i) => (
                    <div
                      key={i}
                      className={`rounded-sm ${
                        [0,1,2,4,5,6,7,13,14,20,21,27,28,34,35,41,42,43,44,45,46,47,48].includes(i) ||
                        Math.random() > 0.5
                          ? "bg-white"
                          : "bg-transparent"
                      }`}
                    />
                  ))}
                </div>
                {/* Center Logo */}
                <div className="absolute bg-primary w-10 h-10 rounded-lg flex items-center justify-center z-10">
                  <QrCode className="w-6 h-6 text-primary-foreground" />
                </div>
              </div>
            </div>
            <div className="text-center">
              <p className="text-sm font-mono text-muted-foreground">
                {product.certificateId}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Escanea para verificar autenticidad
              </p>
            </div>
          </div>

          {/* Product Information */}
          <div className="space-y-5">
            <div>
              <h4 className="text-xl font-bold text-foreground">
                {product.productName}
              </h4>
              <p className="text-muted-foreground">{product.productType}</p>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Building2 className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Productor</p>
                  <p className="font-semibold text-foreground">{product.producerName}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Origen</p>
                  <p className="font-semibold text-foreground">{product.location}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <p className="text-sm text-muted-foreground">Vigencia</p>
                  <p className="font-semibold text-foreground">
                    {product.issueDate} - {product.expiryDate}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-6 rounded-xl overflow-hidden border border-border/30 bg-muted/30">
          <div className="relative h-48 bg-gradient-to-br from-primary/5 to-accent/5">
            {/* Simplified Map Visualization */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative w-full h-full">
                {/* Map grid lines */}
                <div className="absolute inset-4 border border-dashed border-border/50 rounded-lg" />
                <div className="absolute top-1/2 left-0 right-0 h-px bg-border/30" />
                <div className="absolute left-1/2 top-0 bottom-0 w-px bg-border/30" />
                
                {/* Location marker */}
                <div 
                  className="absolute transform -translate-x-1/2 -translate-y-1/2"
                  style={{ top: "45%", left: "55%" }}
                >
                  <div className="relative">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center shadow-lg animate-pulse">
                      <MapPin className="w-5 h-5 text-primary-foreground" />
                    </div>
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-primary rotate-45" />
                  </div>
                </div>

                {/* Coordinates display */}
                <div className="absolute bottom-3 right-3 bg-card/90 backdrop-blur-sm px-3 py-1.5 rounded-lg shadow-sm border border-border/30">
                  <p className="text-xs font-mono text-muted-foreground">
                    {product.coordinates.lat.toFixed(4)}° N, {Math.abs(product.coordinates.lng).toFixed(4)}° W
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div className="px-4 py-3 bg-card/50 border-t border-border/30">
            <p className="text-sm text-muted-foreground">
              Ubicación de la finca o taller de producción
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
