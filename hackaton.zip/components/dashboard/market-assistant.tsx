"use client"

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, Minus, FileText, ArrowRight, Target } from "lucide-react"

type DemandLevel = "high" | "medium" | "low"

interface MarketInfo {
  country: string
  countryCode: string
  flag: string
  demandLevel: DemandLevel
  demandTrend: "up" | "down" | "stable"
  requirements: string[]
  estimatedTime: string
  marketSize: string
}

interface MarketAssistantProps {
  markets: MarketInfo[]
}

export function MarketAssistant({ markets }: MarketAssistantProps) {
  const getDemandConfig = (level: DemandLevel) => {
    const configs = {
      high: {
        label: "Alta Demanda",
        color: "bg-primary text-primary-foreground",
        barColor: "bg-primary",
        barWidth: "w-full",
      },
      medium: {
        label: "Demanda Media",
        color: "bg-warning text-foreground",
        barColor: "bg-warning",
        barWidth: "w-2/3",
      },
      low: {
        label: "Demanda Baja",
        color: "bg-muted text-muted-foreground",
        barColor: "bg-muted-foreground",
        barWidth: "w-1/3",
      },
    }
    return configs[level]
  }

  const getTrendIcon = (trend: "up" | "down" | "stable") => {
    const icons = {
      up: <TrendingUp className="w-4 h-4 text-primary" />,
      down: <TrendingDown className="w-4 h-4 text-destructive" />,
      stable: <Minus className="w-4 h-4 text-muted-foreground" />,
    }
    return icons[trend]
  }

  return (
    <Card className="border-border/50 shadow-lg">
      <CardHeader className="border-b border-border/30">
        <CardTitle className="text-2xl font-bold text-foreground flex items-center gap-2">
          <Target className="w-6 h-6 text-primary" />
          Asistente de Mercados
        </CardTitle>
        <CardDescription className="text-lg text-muted-foreground">
          Análisis de demanda y requisitos por país
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {markets.map((market) => {
            const demandConfig = getDemandConfig(market.demandLevel)
            return (
              <div
                key={market.countryCode}
                className="group p-5 rounded-xl border border-border/50 bg-card hover:shadow-lg hover:border-primary/30 transition-all duration-300"
              >
                {/* Country Header */}
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-5xl">{market.flag}</div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-foreground">
                      {market.country}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Mercado: {market.marketSize}
                    </p>
                  </div>
                </div>

                {/* Demand Level */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge className={demandConfig.color}>
                      {demandConfig.label}
                    </Badge>
                    <div className="flex items-center gap-1">
                      {getTrendIcon(market.demandTrend)}
                      <span className="text-xs text-muted-foreground">
                        {market.demandTrend === "up" ? "Creciendo" : 
                         market.demandTrend === "down" ? "Decreciendo" : "Estable"}
                      </span>
                    </div>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div className={`h-full ${demandConfig.barColor} ${demandConfig.barWidth} rounded-full transition-all`} />
                  </div>
                </div>

                {/* Requirements */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="w-4 h-4 text-primary" />
                    <span className="text-sm font-semibold text-foreground">
                      Requisitos Documentales
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {market.requirements.map((req, idx) => (
                      <li
                        key={idx}
                        className="text-sm text-muted-foreground flex items-start gap-2"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Estimated Time */}
                <div className="pt-4 border-t border-border/30">
                  <p className="text-sm text-muted-foreground mb-3">
                    Tiempo estimado de entrada: <span className="font-semibold text-foreground">{market.estimatedTime}</span>
                  </p>
                  <Button
                    variant="outline"
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                  >
                    Ver detalles
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
