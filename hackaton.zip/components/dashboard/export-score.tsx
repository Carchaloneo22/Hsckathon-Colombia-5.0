"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Sparkles, TrendingUp, AlertCircle, CheckCircle2 } from "lucide-react"

interface ExportScoreProps {
  score: number
  onStartDiagnostic: () => void
}

export function ExportScore({ score, onStartDiagnostic }: ExportScoreProps) {
  const [isAnimating, setIsAnimating] = useState(false)

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-emerald-medium"
    if (score >= 60) return "text-warning"
    return "text-destructive"
  }

  const getScoreLabel = (score: number) => {
    if (score >= 80) return { label: "Excelente", icon: CheckCircle2 }
    if (score >= 60) return { label: "En progreso", icon: TrendingUp }
    return { label: "Requiere atención", icon: AlertCircle }
  }

  const scoreInfo = getScoreLabel(score)
  const ScoreIcon = scoreInfo.icon

  const circumference = 2 * Math.PI * 90
  const strokeDashoffset = circumference - (score / 100) * circumference

  const handleStartDiagnostic = () => {
    setIsAnimating(true)
    setTimeout(() => {
      setIsAnimating(false)
      onStartDiagnostic()
    }, 1500)
  }

  return (
    <Card className="border-border/50 shadow-lg">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl font-bold text-foreground">
          Dashboard de Impacto
        </CardTitle>
        <CardDescription className="text-lg text-muted-foreground">
          Evaluación de preparación para exportación
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center gap-8 pt-4">
        {/* Circular Score Meter */}
        <div className="relative">
          <svg className="w-56 h-56 transform -rotate-90" viewBox="0 0 200 200">
            {/* Background circle */}
            <circle
              cx="100"
              cy="100"
              r="90"
              fill="none"
              stroke="currentColor"
              strokeWidth="12"
              className="text-muted/50"
            />
            {/* Progress circle */}
            <circle
              cx="100"
              cy="100"
              r="90"
              fill="none"
              stroke="currentColor"
              strokeWidth="12"
              strokeLinecap="round"
              className={`${getScoreColor(score)} transition-all duration-1000 ease-out`}
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
            />
          </svg>
          {/* Score display in center */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-6xl font-bold ${getScoreColor(score)}`}>
              {score}
            </span>
            <span className="text-xl text-muted-foreground font-medium">/ 100</span>
            <div className="flex items-center gap-2 mt-2">
              <ScoreIcon className={`w-5 h-5 ${getScoreColor(score)}`} />
              <span className={`text-lg font-semibold ${getScoreColor(score)}`}>
                {scoreInfo.label}
              </span>
            </div>
          </div>
        </div>

        {/* Export-Ready Score Label */}
        <div className="text-center">
          <h3 className="text-xl font-semibold text-foreground mb-1">
            Export-Ready Score
          </h3>
          <p className="text-muted-foreground">
            Tu nivel de preparación para mercados internacionales
          </p>
        </div>

        {/* Start Diagnostic Button */}
        <Button
          size="lg"
          onClick={handleStartDiagnostic}
          disabled={isAnimating}
          className="w-full max-w-sm h-16 text-xl font-bold bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all duration-300"
        >
          {isAnimating ? (
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 border-3 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              <span>Analizando...</span>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <Sparkles className="w-6 h-6" />
              <span>Iniciar Diagnóstico con IA</span>
            </div>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
