"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  FileCheck, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  FileText, 
  Upload, 
  ChevronDown,
  ChevronUp,
  Calendar,
  Building
} from "lucide-react"

type DocumentStatus = "completed" | "pending" | "in-progress" | "expired"

interface Document {
  id: string
  name: string
  description: string
  status: DocumentStatus
  dueDate?: string
  completedDate?: string
  issuingAuthority: string
  requiredFor: string[]
}

interface DocumentManagerProps {
  documents: Document[]
}

export function DocumentManager({ documents }: DocumentManagerProps) {
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null)

  const getStatusConfig = (status: DocumentStatus) => {
    const configs = {
      completed: {
        label: "Completado",
        icon: CheckCircle2,
        color: "bg-primary/10 text-primary border-primary/30",
        iconColor: "text-primary",
      },
      pending: {
        label: "Pendiente",
        icon: Clock,
        color: "bg-warning/10 text-warning border-warning/30",
        iconColor: "text-warning",
      },
      "in-progress": {
        label: "En Proceso",
        icon: FileText,
        color: "bg-info/10 text-info border-info/30",
        iconColor: "text-info",
      },
      expired: {
        label: "Vencido",
        icon: AlertCircle,
        color: "bg-destructive/10 text-destructive border-destructive/30",
        iconColor: "text-destructive",
      },
    }
    return configs[status]
  }

  const completedCount = documents.filter(d => d.status === "completed").length
  const totalCount = documents.length
  const progressPercentage = Math.round((completedCount / totalCount) * 100)

  return (
    <Card className="border-border/50 shadow-lg">
      <CardHeader className="border-b border-border/30">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-2xl font-bold text-foreground flex items-center gap-2">
              <FileCheck className="w-6 h-6 text-primary" />
              Gestor de Documentos
            </CardTitle>
            <CardDescription className="text-lg text-muted-foreground mt-1">
              Control de trámites y certificaciones
            </CardDescription>
          </div>
          
          {/* Progress Summary */}
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Progreso total</p>
              <p className="text-2xl font-bold text-foreground">
                {completedCount}/{totalCount}
              </p>
            </div>
            <div className="relative w-16 h-16">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <circle
                  cx="18"
                  cy="18"
                  r="14"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  className="text-muted"
                />
                <circle
                  cx="18"
                  cy="18"
                  r="14"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  className="text-primary"
                  strokeDasharray={`${progressPercentage * 0.88} 100`}
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-sm font-bold text-foreground">
                {progressPercentage}%
              </span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-3">
          {documents.map((doc) => {
            const statusConfig = getStatusConfig(doc.status)
            const StatusIcon = statusConfig.icon
            const isExpanded = expandedDoc === doc.id

            return (
              <div
                key={doc.id}
                className={`border rounded-xl transition-all duration-300 ${
                  isExpanded ? "border-primary/50 shadow-md" : "border-border/50"
                }`}
              >
                {/* Main Row */}
                <div
                  className="flex items-center gap-4 p-4 cursor-pointer hover:bg-muted/30 rounded-xl transition-colors"
                  onClick={() => setExpandedDoc(isExpanded ? null : doc.id)}
                >
                  {/* Status Icon */}
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${statusConfig.color} border`}>
                    <StatusIcon className={`w-6 h-6 ${statusConfig.iconColor}`} />
                  </div>

                  {/* Document Info */}
                  <div className="flex-1 min-w-0">
                    <h4 className="text-lg font-semibold text-foreground truncate">
                      {doc.name}
                    </h4>
                    <p className="text-sm text-muted-foreground truncate">
                      {doc.description}
                    </p>
                  </div>

                  {/* Status Badge */}
                  <Badge className={`${statusConfig.color} border hidden sm:flex`}>
                    {statusConfig.label}
                  </Badge>

                  {/* Expand Button */}
                  <Button variant="ghost" size="sm" className="p-2">
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-muted-foreground" />
                    )}
                  </Button>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="px-4 pb-4 pt-0 border-t border-border/30 mt-0">
                    <div className="pt-4 grid sm:grid-cols-2 gap-4">
                      {/* Issuing Authority */}
                      <div className="flex items-start gap-3">
                        <Building className="w-5 h-5 text-primary mt-0.5" />
                        <div>
                          <p className="text-sm text-muted-foreground">Entidad emisora</p>
                          <p className="font-medium text-foreground">{doc.issuingAuthority}</p>
                        </div>
                      </div>

                      {/* Date */}
                      <div className="flex items-start gap-3">
                        <Calendar className="w-5 h-5 text-primary mt-0.5" />
                        <div>
                          <p className="text-sm text-muted-foreground">
                            {doc.status === "completed" ? "Fecha de emisión" : "Fecha límite"}
                          </p>
                          <p className="font-medium text-foreground">
                            {doc.completedDate || doc.dueDate || "Por definir"}
                          </p>
                        </div>
                      </div>

                      {/* Required For */}
                      <div className="sm:col-span-2">
                        <p className="text-sm text-muted-foreground mb-2">Requerido para:</p>
                        <div className="flex flex-wrap gap-2">
                          {doc.requiredFor.map((market, idx) => (
                            <Badge key={idx} variant="secondary" className="text-sm">
                              {market}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Actions */}
                      {doc.status !== "completed" && (
                        <div className="sm:col-span-2 pt-2">
                          <Button className="w-full sm:w-auto">
                            <Upload className="w-4 h-4 mr-2" />
                            Subir documento
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
