'use client'

import { cn } from '@/lib/utils'

type UserRole = 'comerciante' | 'comprador'

interface RoleSelectorProps {
  value: UserRole
  onChange: (role: UserRole) => void
  disabled?: boolean
}

export function RoleSelector({ value, onChange, disabled }: RoleSelectorProps) {
  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Comerciante */}
      <button
        type="button"
        onClick={() => !disabled && onChange('comerciante')}
        disabled={disabled}
        className={cn(
          "group relative flex flex-col items-center gap-4 p-6 rounded-2xl border-2 transition-all duration-500 ease-out",
          "hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed",
          value === 'comerciante'
            ? 'border-primary bg-gradient-to-br from-primary/15 via-primary/10 to-primary/5 shadow-lg shadow-primary/25 scale-[1.02]'
            : 'border-border hover:border-primary/50 hover:bg-muted/30 hover:scale-[1.01]'
        )}
      >
        {/* Animated ring */}
        <div className={cn(
          "absolute inset-0 rounded-2xl transition-all duration-500",
          value === 'comerciante' 
            ? 'ring-2 ring-primary/30 ring-offset-2 ring-offset-background' 
            : 'ring-0'
        )} />

        {/* Check indicator with bounce animation */}
        <div className={cn(
          "absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all duration-500",
          value === 'comerciante' 
            ? 'bg-primary scale-100 opacity-100 animate-[bounce_0.5s_ease-out]' 
            : 'bg-muted scale-0 opacity-0'
        )}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        
        {/* Icon Container with pulse effect */}
        <div className={cn(
          "relative w-20 h-20 rounded-2xl flex items-center justify-center transition-all duration-500",
          value === 'comerciante' 
            ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/40' 
            : 'bg-muted text-muted-foreground group-hover:bg-primary/15 group-hover:text-primary'
        )}>
          {/* Pulse ring when selected */}
          <div className={cn(
            "absolute inset-0 rounded-2xl bg-primary/20 transition-all duration-700",
            value === 'comerciante' ? 'animate-ping opacity-75' : 'opacity-0'
          )} style={{ animationDuration: '2s', animationIterationCount: 'infinite' }} />
          
          {/* Store/Shop Icon */}
          <svg 
            width="40" 
            height="40" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="1.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className={cn(
              "relative z-10 transition-all duration-500",
              "group-hover:scale-110",
              value === 'comerciante' && 'scale-110'
            )}
          >
            {/* Building with awning - store icon */}
            <path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z"/>
            <path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9"/>
            <path d="M12 3v6"/>
            {/* Dollar sign in store */}
            <path d="M12 13v6"/>
            <path d="M9 16h6"/>
            <path d="M9 13h6"/>
          </svg>
        </div>
        
        {/* Label with animated underline */}
        <div className="text-center relative">
          <span className={cn(
            "block text-lg font-bold transition-all duration-500",
            value === 'comerciante' ? 'text-primary' : 'text-foreground group-hover:text-primary'
          )}>
            Comerciante
          </span>
          <span className="text-sm text-muted-foreground mt-1 block">
            Vende y exporta productos
          </span>
          {/* Animated underline */}
          <div className={cn(
            "absolute -bottom-1 left-1/2 h-0.5 bg-primary rounded-full transition-all duration-500",
            value === 'comerciante' ? 'w-full -translate-x-1/2' : 'w-0 -translate-x-1/2'
          )} />
        </div>
      </button>

      {/* Comprador */}
      <button
        type="button"
        onClick={() => !disabled && onChange('comprador')}
        disabled={disabled}
        className={cn(
          "group relative flex flex-col items-center gap-4 p-6 rounded-2xl border-2 transition-all duration-500 ease-out",
          "hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed",
          value === 'comprador'
            ? 'border-primary bg-gradient-to-br from-primary/15 via-primary/10 to-primary/5 shadow-lg shadow-primary/25 scale-[1.02]'
            : 'border-border hover:border-primary/50 hover:bg-muted/30 hover:scale-[1.01]'
        )}
      >
        {/* Animated ring */}
        <div className={cn(
          "absolute inset-0 rounded-2xl transition-all duration-500",
          value === 'comprador' 
            ? 'ring-2 ring-primary/30 ring-offset-2 ring-offset-background' 
            : 'ring-0'
        )} />

        {/* Check indicator with bounce animation */}
        <div className={cn(
          "absolute top-3 right-3 w-6 h-6 rounded-full flex items-center justify-center transition-all duration-500",
          value === 'comprador' 
            ? 'bg-primary scale-100 opacity-100 animate-[bounce_0.5s_ease-out]' 
            : 'bg-muted scale-0 opacity-0'
        )}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        
        {/* Icon Container with pulse effect */}
        <div className={cn(
          "relative w-20 h-20 rounded-2xl flex items-center justify-center transition-all duration-500",
          value === 'comprador' 
            ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/40' 
            : 'bg-muted text-muted-foreground group-hover:bg-primary/15 group-hover:text-primary'
        )}>
          {/* Pulse ring when selected */}
          <div className={cn(
            "absolute inset-0 rounded-2xl bg-primary/20 transition-all duration-700",
            value === 'comprador' ? 'animate-ping opacity-75' : 'opacity-0'
          )} style={{ animationDuration: '2s', animationIterationCount: 'infinite' }} />
          
          {/* Shopping Cart Icon */}
          <svg 
            width="40" 
            height="40" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="1.5" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className={cn(
              "relative z-10 transition-all duration-500",
              "group-hover:scale-110",
              value === 'comprador' && 'scale-110'
            )}
          >
            {/* Globe with cart - international buyer */}
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
            <path d="M2 12h20"/>
            {/* Small cart overlay */}
            <circle cx="18" cy="18" r="4" fill="currentColor" stroke="none"/>
            <path d="M16 17.5l1 1.5h2" stroke="white" strokeWidth="1"/>
          </svg>
        </div>
        
        {/* Label with animated underline */}
        <div className="text-center relative">
          <span className={cn(
            "block text-lg font-bold transition-all duration-500",
            value === 'comprador' ? 'text-primary' : 'text-foreground group-hover:text-primary'
          )}>
            Comprador
          </span>
          <span className="text-sm text-muted-foreground mt-1 block">
            Importa y compra productos
          </span>
          {/* Animated underline */}
          <div className={cn(
            "absolute -bottom-1 left-1/2 h-0.5 bg-primary rounded-full transition-all duration-500",
            value === 'comprador' ? 'w-full -translate-x-1/2' : 'w-0 -translate-x-1/2'
          )} />
        </div>
      </button>
    </div>
  )
}
