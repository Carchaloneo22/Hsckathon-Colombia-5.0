'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'

type ActivePage = 'dashboard' | 'catalog' | 'quotes' | 'orders' | 'messages' | 'profile'

interface BuyerLayoutProps {
  children: React.ReactNode
  activePage: ActivePage
  lang?: 'ES' | 'EN'
  onLangChange?: (lang: 'ES' | 'EN') => void
}

const NAV_ITEMS = [
  {
    id: 'dashboard' as ActivePage,
    labelES: 'Inicio',
    labelEN: 'Home',
    href: '/buyer/dashboard',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
        <polyline points="9 22 9 12 15 12 15 22"/>
      </svg>
    ),
  },
  {
    id: 'catalog' as ActivePage,
    labelES: 'Catálogo',
    labelEN: 'Catalog',
    href: '/buyer/catalog',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
      </svg>
    ),
  },
  {
    id: 'quotes' as ActivePage,
    labelES: 'Cotizaciones',
    labelEN: 'Quotes',
    href: '/buyer/quotes',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
        <line x1="16" y1="13" x2="8" y2="13"/>
        <line x1="16" y1="17" x2="8" y2="17"/>
        <polyline points="10 9 9 9 8 9"/>
      </svg>
    ),
    badge: 3,
  },
  {
    id: 'orders' as ActivePage,
    labelES: 'Pedidos',
    labelEN: 'Orders',
    href: '/buyer/orders',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="1" y="3" width="15" height="13"/>
        <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/>
        <circle cx="5.5" cy="18.5" r="2.5"/>
        <circle cx="18.5" cy="18.5" r="2.5"/>
      </svg>
    ),
    badge: 1,
  },
  {
    id: 'messages' as ActivePage,
    labelES: 'Mensajes',
    labelEN: 'Messages',
    href: '/buyer/messages',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
    ),
    badge: 2,
  },
  {
    id: 'profile' as ActivePage,
    labelES: 'Perfil',
    labelEN: 'Profile',
    href: '/buyer/profile',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
        <circle cx="12" cy="7" r="4"/>
      </svg>
    ),
  },
]

export function BuyerLayout({ children, activePage, lang = 'ES', onLangChange }: BuyerLayoutProps) {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-card border-b border-border">
        <div className="flex items-center justify-between px-4 py-3 max-w-7xl mx-auto">
          {/* Logo */}
          <Link href="/buyer/dashboard" className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center flex-none shadow-sm">
              <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
                <circle cx="9" cy="9" r="7" stroke="white" strokeWidth="1.5"/>
                <circle cx="9" cy="9" r="2" fill="white"/>
                <line x1="9" y1="2" x2="9" y2="5.5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="9" y1="12.5" x2="9" y2="16" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="2" y1="9" x2="5.5" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="12.5" y1="9" x2="16" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <div className="hidden sm:block">
              <span className="font-bold text-foreground text-sm leading-none block">Exporta Santander</span>
              <span className="text-[10px] text-muted-foreground leading-none">Hecho en Colombia · Exportado al mundo</span>
            </div>
          </Link>

          {/* Search (desktop) */}
          <div className="hidden md:flex flex-1 max-w-sm mx-4">
            <div className="relative w-full">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
              </svg>
              <input
                type="search"
                placeholder={lang === 'ES' ? 'Buscar productos, productores...' : 'Search products, producers...'}
                className="w-full pl-9 pr-4 py-2 text-sm bg-muted border border-border rounded-xl focus:outline-none focus:border-primary text-foreground placeholder:text-muted-foreground"
              />
            </div>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            {/* Lang toggle */}
            {onLangChange && (
              <button
                onClick={() => onLangChange(lang === 'ES' ? 'EN' : 'ES')}
                className="text-xs font-medium px-2.5 py-1.5 rounded-lg border border-border bg-muted hover:bg-accent/10 text-foreground transition-colors"
              >
                {lang === 'ES' ? 'EN' : 'ES'}
              </button>
            )}

            {/* Notifications */}
            <button className="relative p-2 rounded-xl hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
              </svg>
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-destructive rounded-full" />
            </button>

            {/* Profile */}
            <Link
              href="/buyer/profile"
              className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-muted transition-colors"
            >
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-sm">
                MG
              </div>
            </Link>

            {/* Logout */}
            <button
              onClick={() => router.push('/bienvenida')}
              className="hidden md:flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                <polyline points="16 17 21 12 16 7"/>
                <line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              {lang === 'ES' ? 'Salir' : 'Logout'}
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 max-w-7xl mx-auto w-full">
        {/* Desktop Left Sidebar */}
        <aside className="hidden md:flex flex-col w-56 flex-none border-r border-border bg-card min-h-full pt-4 pb-6 sticky top-[57px] self-start h-[calc(100vh-57px)]">
          <nav className="flex-1 px-3 space-y-1">
            {NAV_ITEMS.map((item) => {
              const isActive = activePage === item.id
              return (
                <Link
                  key={item.id}
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 group relative ${
                    isActive
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  <span className={`flex-none transition-transform duration-150 ${isActive ? '' : 'group-hover:scale-110'}`}>
                    {item.icon}
                  </span>
                  <span className="flex-1">{lang === 'ES' ? item.labelES : item.labelEN}</span>
                  {item.badge && !isActive && (
                    <span className="bg-destructive text-destructive-foreground text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                      {item.badge}
                    </span>
                  )}
                </Link>
              )
            })}
          </nav>

          {/* Sidebar footer */}
          <div className="px-3 pt-4 border-t border-border mx-3 mt-4">
            <div className="flex items-center gap-2 px-1">
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center text-primary font-semibold text-xs flex-none">
                MG
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-foreground truncate">Maria Gonzalez</p>
                <p className="text-[10px] text-muted-foreground truncate">Comprador Internacional</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0 px-4 md:px-6 py-6 pb-24 md:pb-6">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-card border-t border-border">
        <div className="flex items-center justify-around px-2 py-2">
          {NAV_ITEMS.map((item) => {
            const isActive = activePage === item.id
            return (
              <Link
                key={item.id}
                href={item.href}
                className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-xl transition-colors relative ${
                  isActive ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                {item.badge && (
                  <span className="absolute -top-0.5 right-1.5 w-4 h-4 bg-destructive text-destructive-foreground text-[9px] font-bold rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
                {item.icon}
                <span className="text-[10px] font-medium leading-none">
                  {lang === 'ES' ? item.labelES : item.labelEN}
                </span>
              </Link>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
