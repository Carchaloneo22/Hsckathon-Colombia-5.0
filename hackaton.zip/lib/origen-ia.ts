import { useState, useEffect } from "react";

async function callClaude(messages) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: "Eres experto en exportaciones colombianas y comercio internacional. Responde ÚNICAMENTE con JSON válido, sin markdown, sin texto adicional.",
      messages,
    }),
  });
  const data = await res.json();
  const text = data.content?.find((b) => b.type === "text")?.text || "{}";
  return JSON.parse(text.replace(/```json|```/g, "").trim());
}

const STEPS = [
  { id: 1, label: "Empresa" },
  { id: 2, label: "Score IA" },
  { id: 3, label: "Perfil" },
  { id: 4, label: "QR Lote" },
  { id: 5, label: "Documentos" },
];

const SECTORES = ["Cacao fino de aroma","Joyería artesanal","Calzado","Manufactura","Cítricos","Otro"];
const MUNICIPIOS = ["Bucaramanga","San Vicente de Chucurí","El Carmen de Chucurí","Landázuri","Lebrija","Girón","Piedecuesta","Barrancabermeja","Otro"];
const PAISES = ["Alemania","Estados Unidos","Francia","Países Bajos","Japón","Reino Unido","España","Canadá","Italia","Bélgica"];

// ── LANDING ──────────────────────────────────────────────────────────────────

function Landing({ onStart }) {
  return (
    <div className="min-h-screen bg-white">
      <nav className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <circle cx="9" cy="9" r="7" stroke="white" strokeWidth="1.5"/>
              <circle cx="9" cy="9" r="2" fill="white"/>
              <line x1="9" y1="2" x2="9" y2="5.5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              <line x1="9" y1="12.5" x2="9" y2="16" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              <line x1="2" y1="9" x2="5.5" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              <line x1="12.5" y1="9" x2="16" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </div>
          <span className="font-semibold text-gray-900 text-lg">OrigenIA</span>
        </div>
        <button onClick={onStart} className="bg-teal-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-teal-700">
          Comenzar gratis
        </button>
      </nav>

      <div className="max-w-3xl mx-auto px-6 pt-20 pb-12 text-center">
        <span className="inline-block bg-teal-50 text-teal-700 text-sm px-4 py-2 rounded-full mb-6 border border-teal-100">
          Foco Colombia 5.0 · Exportación Digital · Santander
        </span>
        <h1 className="text-4xl font-bold text-gray-900 mb-5 leading-snug">
          Tu co-piloto de exportación<br/>digital para MIPYMES
        </h1>
        <p className="text-lg text-gray-500 mb-8 max-w-xl mx-auto leading-relaxed">
          Transforma tu empresa de Santander en una exportadora. Score exportador, perfil multilingüe, trazabilidad QR, documentación automática y match de mercados — todo en un flujo con IA real.
        </p>
        <button onClick={onStart} className="bg-teal-600 text-white px-8 py-4 rounded-xl text-base font-medium hover:bg-teal-700 shadow-sm">
          Evalúa tu empresa ahora
        </button>
        <p className="text-sm text-gray-400 mt-3">Sin registro · 5 módulos · Resultado inmediato con IA</p>
      </div>

      <div className="max-w-3xl mx-auto px-6">
        <div className="flex flex-wrap justify-center gap-2 mb-16">
          {SECTORES.filter(s => s !== "Otro").map(s => (
            <span key={s} className="bg-gray-100 text-gray-600 text-sm px-3 py-1.5 rounded-full">{s}</span>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-4 mb-16">
          {[
            { dot: "bg-teal-500", title: "Score exportador IA", desc: "Diagnóstico 0-100 de tu preparación exportadora con fortalezas, brechas y plan de acción personalizado." },
            { dot: "bg-green-500", title: "Trazabilidad QR", desc: "QR escaneable por lote con cadena de custodia completa. El comprador internacional verifica el origen en segundos." },
            { dot: "bg-purple-500", title: "Documentación automática", desc: "La IA genera todos los documentos necesarios según el país de destino: certificado de origen, factura, checklist aduanero." },
            { dot: "bg-amber-500", title: "Match de mercados", desc: "Identifica los mejores países compradores para tu producto con datos reales de importaciones mundiales." },
          ].map(f => (
            <div key={f.title} className="bg-gray-50 rounded-xl p-5 border border-gray-100">
              <div className={`w-2.5 h-2.5 rounded-full ${f.dot} mb-3`}></div>
              <h3 className="font-semibold text-gray-900 mb-1.5 text-sm">{f.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>

        <div className="text-center pb-20">
          <button onClick={onStart} className="bg-teal-600 text-white px-8 py-4 rounded-xl text-base font-medium hover:bg-teal-700">
            Comenzar evaluación gratuita
          </button>
        </div>
      </div>
    </div>
  );
}

// ── STEP BAR ─────────────────────────────────────────────────────────────────

function StepBar({ current }) {
  return (
    <div className="flex items-center justify-between mb-8">
      {STEPS.map((s, i) => (
        <div key={s.id} className="flex items-center">
          <div className="flex items-center gap-1.5">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold border-2 transition-colors ${s.id < current ? "bg-teal-600 border-teal-600 text-white" : s.id === current ? "border-teal-600 text-teal-600 bg-white" : "border-gray-200 text-gray-400 bg-white"}`}>
              {s.id < current ? "✓" : s.id}
            </div>
            <span className={`text-xs hidden sm:block ${s.id <= current ? "text-teal-700 font-medium" : "text-gray-400"}`}>{s.label}</span>
          </div>
          {i < STEPS.length - 1 && (
            <div className={`h-px mx-2 sm:mx-3 w-8 sm:w-10 ${s.id < current ? "bg-teal-400" : "bg-gray-200"}`}></div>
          )}
        </div>
      ))}
    </div>
  );
}

// ── STEP 1: FORM ──────────────────────────────────────────────────────────────

function Step1({ formData, setFormData, onNext }) {
  const ok = formData.empresa && formData.sector && formData.municipio && formData.producto;
  const set = (k, v) => setFormData(prev => ({ ...prev, [k]: v }));

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-1">Cuéntanos sobre tu empresa</h2>
      <p className="text-sm text-gray-500 mb-6">La IA usará esta información para evaluar tu potencial exportador.</p>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Nombre de la empresa *</label>
          <input value={formData.empresa} onChange={e => set("empresa", e.target.value)} placeholder="Ej. Cacao del Oriente SAS" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Sector *</label>
            <select value={formData.sector} onChange={e => set("sector", e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400">
              <option value="">Seleccionar...</option>
              {SECTORES.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Municipio *</label>
            <select value={formData.municipio} onChange={e => set("municipio", e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400">
              <option value="">Seleccionar...</option>
              {MUNICIPIOS.map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Descripción del producto principal *</label>
          <textarea value={formData.producto} onChange={e => set("producto", e.target.value)} placeholder="Ej. Cacao fino de aroma, variedad Criollo, fermentación artesanal 5 días, secado solar..." rows={3} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400 resize-none" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Volumen mensual disponible</label>
            <input value={formData.volumen} onChange={e => set("volumen", e.target.value)} placeholder="Ej. 2 toneladas/mes" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Años en operación</label>
            <input value={formData.anos} onChange={e => set("anos", e.target.value)} placeholder="Ej. 5" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400" />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Certificaciones actuales</label>
          <input value={formData.certificaciones} onChange={e => set("certificaciones", e.target.value)} placeholder="Ej. Orgánico, UTZ, Rainforest Alliance, o Ninguna" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-teal-400" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Experiencia exportadora</label>
          <div className="flex gap-2">
            {["No, nunca", "En proceso", "Sí, tengo experiencia"].map(o => (
              <button key={o} onClick={() => set("experiencia", o)} className={`flex-1 py-2 px-2 rounded-lg text-xs border transition-colors ${formData.experiencia === o ? "border-teal-500 bg-teal-50 text-teal-700" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}>{o}</button>
            ))}
          </div>
        </div>
      </div>

      <button onClick={onNext} disabled={!ok} className={`mt-6 w-full py-3 rounded-xl font-medium text-sm transition-colors ${ok ? "bg-teal-600 text-white hover:bg-teal-700" : "bg-gray-100 text-gray-400 cursor-not-allowed"}`}>
        Evaluar mi empresa con IA
      </button>
    </div>
  );
}

// ── STEP 2: SCORE ─────────────────────────────────────────────────────────────

function Step2({ formData, scoreData, setScoreData, onNext }) {
  const [loading, setLoading] = useState(!scoreData);

  useEffect(() => {
    if (scoreData) return;
    callClaude([{ role: "user", content: `Analiza esta MIPYME de Santander y devuelve este JSON exacto:
Empresa: ${formData.empresa} | Sector: ${formData.sector} | Municipio: ${formData.municipio}
Producto: ${formData.producto} | Volumen: ${formData.volumen} | Años: ${formData.anos}
Certificaciones: ${formData.certificaciones} | Experiencia: ${formData.experiencia}

{"score":número_0_100,"nivel":"Inicial|En desarrollo|Avanzado|Listo para exportar","resumen":"2 oraciones sobre potencial exportador","fortalezas":["f1","f2","f3"],"brechas":["b1","b2","b3"],"acciones":["acción1","acción2","acción3"],"dimensiones":{"producto":número,"documentacion":número,"mercado":número,"capacidad":número}}` }])
      .then(r => { setScoreData(r); setLoading(false); })
      .catch(() => {
        setScoreData({ score: 64, nivel: "En desarrollo", resumen: "Tu empresa tiene un producto con potencial exportador real en mercados europeos y asiáticos. Con certificaciones internacionales y documentación adecuada, podrías estar exportando en 6-12 meses.", fortalezas: ["Producto diferenciado con características únicas de origen", "Ubicación estratégica en Santander, epicentro cacaotero", "Experiencia productiva consolidada"], brechas: ["Ausencia de certificaciones internacionales reconocidas", "Sin perfil digital en idiomas extranjeros", "Documentación exportadora inexistente"], acciones: ["Iniciar proceso de certificación Rainforest Alliance o UTZ", "Crear ficha técnica del producto en inglés y alemán", "Contactar ProColombia para asesoría exportadora gratuita"], dimensiones: { producto: 75, documentacion: 30, mercado: 55, capacidad: 65 } });
        setLoading(false);
      });
  }, []);

  if (loading) return (
    <div className="text-center py-20">
      <div className="w-12 h-12 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
      <p className="text-gray-700 font-medium">Analizando tu empresa con IA...</p>
      <p className="text-gray-400 text-sm mt-1">Calculando score exportador y plan de acción</p>
    </div>
  );

  const { score, nivel, resumen, fortalezas, brechas, acciones, dimensiones } = scoreData;
  const scoreColor = score >= 70 ? "text-teal-600" : score >= 45 ? "text-amber-500" : "text-red-500";
  const levelBg = score >= 70 ? "bg-teal-100 text-teal-700" : score >= 45 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-600";
  const dimLabels = { producto: "Producto", documentacion: "Documentación", mercado: "Mercado", capacidad: "Capacidad" };
  const barColor = (v) => v >= 70 ? "bg-teal-500" : v >= 45 ? "bg-amber-400" : "bg-red-400";

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-1">Score exportador</h2>
      <p className="text-sm text-gray-500 mb-5">{formData.empresa} · {formData.sector}</p>

      <div className="bg-gray-50 rounded-2xl p-6 mb-5 text-center">
        <div className={`text-7xl font-bold ${scoreColor} leading-none mb-1`}>{score}</div>
        <div className="text-gray-400 text-sm mb-3">puntos de 100</div>
        <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${levelBg}`}>{nivel}</span>
        <p className="text-gray-600 text-sm mt-4 leading-relaxed max-w-sm mx-auto">{resumen}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-5">
        {Object.entries(dimensiones || {}).map(([k, v]) => (
          <div key={k} className="bg-white border border-gray-100 rounded-xl p-3">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-gray-500">{dimLabels[k] || k}</span>
              <span className="text-sm font-semibold text-gray-800">{v}</span>
            </div>
            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
              <div className={`h-1.5 rounded-full ${barColor(v)}`} style={{ width: `${v}%` }}></div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-5">
        <div>
          <h4 className="text-sm font-semibold text-gray-700 mb-2">Fortalezas</h4>
          {fortalezas?.map((f, i) => (
            <div key={i} className="flex items-start gap-2 mb-2">
              <span className="text-teal-500 mt-0.5 text-xs font-bold flex-shrink-0">✓</span>
              <span className="text-xs text-gray-600 leading-relaxed">{f}</span>
            </div>
          ))}
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-700 mb-2">Brechas a cerrar</h4>
          {brechas?.map((b, i) => (
            <div key={i} className="flex items-start gap-2 mb-2">
              <span className="text-amber-500 mt-0.5 text-xs font-bold flex-shrink-0">!</span>
              <span className="text-xs text-gray-600 leading-relaxed">{b}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-teal-50 rounded-xl p-4 mb-6">
        <h4 className="text-sm font-semibold text-teal-800 mb-2">Plan de acción prioritario</h4>
        {acciones?.map((a, i) => (
          <div key={i} className="flex items-start gap-2 mb-2 last:mb-0">
            <span className="text-teal-600 font-bold text-sm flex-shrink-0">{i + 1}.</span>
            <span className="text-sm text-teal-700 leading-relaxed">{a}</span>
          </div>
        ))}
      </div>

      <button onClick={onNext} className="w-full py-3 bg-teal-600 text-white rounded-xl font-medium hover:bg-teal-700">
        Generar perfil internacional
      </button>
    </div>
  );
}

// ── STEP 3: PROFILE ───────────────────────────────────────────────────────────

function Step3({ formData, profileData, setProfileData, onNext }) {
  const [loading, setLoading] = useState(!profileData);
  const [lang, setLang] = useState("es");

  useEffect(() => {
    if (profileData) return;
    callClaude([{ role: "user", content: `Genera perfil exportador para esta MIPYME de Santander:
Empresa: ${formData.empresa} | Sector: ${formData.sector} | Municipio: ${formData.municipio}
Producto: ${formData.producto} | Volumen: ${formData.volumen} | Certificaciones: ${formData.certificaciones}

Responde SOLO con este JSON:
{"es":{"titulo":"nombre comercial atractivo","descripcion":"párrafo 3 oraciones para compradores B2B","ficha":{"Origen":"...","Proceso":"...","Calidad":"...","Diferenciador":"...","Disponibilidad":"..."},"historia":"historia del productor 2 oraciones"},"en":{"titulo":"...","descripcion":"...","ficha":{"Origin":"...","Process":"...","Quality":"...","Differentiator":"...","Availability":"..."},"historia":"..."},"de":{"titulo":"...","descripcion":"...","ficha":{"Herkunft":"...","Prozess":"...","Qualität":"...","Alleinstellungsmerkmal":"...","Verfügbarkeit":"..."},"historia":"..."}}` }])
      .then(r => { setProfileData(r); setLoading(false); })
      .catch(() => {
        const makeProfile = (lang) => {
          const titles = { es: `${formData.producto || formData.sector} · ${formData.municipio}, Santander`, en: `${formData.producto || formData.sector} · ${formData.municipio}, Santander, Colombia`, de: `${formData.producto || formData.sector} · ${formData.municipio}, Santander, Kolumbien` };
          const descs = { es: `Producto de origen colombiano cultivado con técnicas artesanales en las montañas de Santander. Nuestro proceso garantiza la más alta calidad y trazabilidad completa desde la finca hasta el comprador. Disponible para exportación con volúmenes consistentes y estándares superiores de calidad.`, en: `Colombian origin product grown with artisanal techniques in the mountains of Santander. Our process guarantees the highest quality and full traceability from farm to international buyer. Available for export with consistent volumes and superior quality standards.`, de: `Produkt kolumbianischen Ursprungs, angebaut mit handwerklichen Techniken in den Bergen von Santander. Unser Prozess garantiert höchste Qualität und vollständige Rückverfolgbarkeit vom Hof bis zum internationalen Käufer.` };
          const fichas = { es: { "Origen": `${formData.municipio}, Santander, Colombia`, "Proceso": "Artesanal, fermentación controlada", "Calidad": "Premium certificado", "Diferenciador": "Trazabilidad verificada, origen único", "Disponibilidad": formData.volumen || "Consultar" }, en: { "Origin": `${formData.municipio}, Santander, Colombia`, "Process": "Artisanal, controlled fermentation", "Quality": "Certified premium", "Differentiator": "Verified traceability, unique origin", "Availability": formData.volumen || "On request" }, de: { "Herkunft": `${formData.municipio}, Santander, Kolumbien`, "Prozess": "Handwerklich, kontrollierte Fermentation", "Qualität": "Zertifiziertes Premium", "Alleinstellungsmerkmal": "Verifizierte Rückverfolgbarkeit", "Verfügbarkeit": formData.volumen || "Auf Anfrage" } };
          const historias = { es: `${formData.empresa} lleva ${formData.anos || "varios"} años produciendo con dedicación en las tierras de Santander, manteniendo las tradiciones artesanales que hacen único cada lote.`, en: `${formData.empresa} has been producing with dedication in the lands of Santander for ${formData.anos || "several"} years, maintaining artisanal traditions that make each lot unique.`, de: `${formData.empresa} produziert seit ${formData.anos || "mehreren"} Jahren mit Leidenschaft auf den Böden von Santander.` };
          return { titulo: titles[lang], descripcion: descs[lang], ficha: fichas[lang], historia: historias[lang] };
        };
        setProfileData({ es: makeProfile("es"), en: makeProfile("en"), de: makeProfile("de") });
        setLoading(false);
      });
  }, []);

  if (loading) return (
    <div className="text-center py-20">
      <div className="w-12 h-12 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
      <p className="text-gray-700 font-medium">Generando perfil internacional...</p>
      <p className="text-gray-400 text-sm mt-1">Creando tu ficha en español, inglés y alemán</p>
    </div>
  );

  const d = profileData?.[lang];

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-1">Perfil exportador</h2>
      <p className="text-sm text-gray-500 mb-5">Tu ficha internacional lista para compartir con compradores B2B.</p>

      <div className="flex gap-2 mb-5">
        {[["es","Español"],["en","English"],["de","Deutsch"]].map(([k, v]) => (
          <button key={k} onClick={() => setLang(k)} className={`px-4 py-2 rounded-lg text-sm font-medium border transition-colors ${lang === k ? "bg-teal-600 text-white border-teal-600" : "border-gray-200 text-gray-600 hover:border-teal-300"}`}>{v}</button>
        ))}
      </div>

      {d && (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden mb-5">
          <div className="bg-teal-600 px-5 py-4">
            <div className="text-white font-semibold">{d.titulo}</div>
            <div className="text-teal-200 text-xs mt-1">{formData.empresa} · {formData.municipio}, Santander, Colombia</div>
          </div>
          <div className="p-5">
            <p className="text-sm text-gray-600 leading-relaxed mb-4">{d.descripcion}</p>
            <div className="bg-gray-50 rounded-lg p-3 mb-4">
              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">Ficha técnica</div>
              {Object.entries(d.ficha || {}).map(([k, v]) => (
                <div key={k} className="flex justify-between py-1.5 border-b border-gray-100 last:border-0 text-sm">
                  <span className="text-gray-500 flex-shrink-0 mr-4">{k}</span>
                  <span className="text-gray-800 font-medium text-right">{v}</span>
                </div>
              ))}
            </div>
            <div className="bg-teal-50 rounded-lg p-3">
              <div className="text-xs font-semibold text-teal-700 mb-1">Historia del productor</div>
              <p className="text-sm text-teal-800 leading-relaxed">{d.historia}</p>
            </div>
          </div>
        </div>
      )}

      <button onClick={onNext} className="w-full py-3 bg-teal-600 text-white rounded-xl font-medium hover:bg-teal-700">
        Generar trazabilidad QR
      </button>
    </div>
  );
}

// ── STEP 4: QR ────────────────────────────────────────────────────────────────

function Step4({ formData, onNext }) {
  const [lote, setLote] = useState({
    fecha: new Date().toISOString().split("T")[0],
    peso: "",
    proceso: formData.sector?.includes("Cacao") ? "Fermentación 5 días + secado solar" : "Proceso artesanal controlado",
    calidad: "Premium A",
  });
  const loteId = `SAN-${(formData.sector || "PRD").substring(0, 3).toUpperCase()}-${Date.now().toString().slice(-6)}`;
  const qrText = `OrigenIA | ${formData.empresa} | Lote: ${loteId} | ${formData.sector} | ${formData.municipio}, Santander | Fecha: ${lote.fecha} | Peso: ${lote.peso || "N/D"} | Proceso: ${lote.proceso} | Calidad: ${lote.calidad}`;
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(qrText)}`;
  const set = (k, v) => setLote(prev => ({ ...prev, [k]: v }));

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-1">Trazabilidad QR por lote</h2>
      <p className="text-sm text-gray-500 mb-6">Registra los datos del lote y genera el código QR de trazabilidad escaneable.</p>

      <div className="grid grid-cols-2 gap-3 mb-5">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Fecha de producción</label>
          <input type="date" value={lote.fecha} onChange={e => set("fecha", e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Peso del lote</label>
          <input value={lote.peso} onChange={e => set("peso", e.target.value)} placeholder="Ej. 450 kg" className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Proceso aplicado</label>
          <input value={lote.proceso} onChange={e => set("proceso", e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Clasificación de calidad</label>
          <select value={lote.calidad} onChange={e => set("calidad", e.target.value)} className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm">
            {["Premium A","Premium B","Estándar","Industrial"].map(c => <option key={c}>{c}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-gray-50 rounded-xl p-5 flex gap-5 mb-4">
        <div className="text-center flex-shrink-0">
          <img src={qrUrl} alt="QR Trazabilidad" className="w-40 h-40 rounded-lg border border-gray-200 bg-white" />
          <div className="text-xs text-gray-500 mt-2 font-mono">{loteId}</div>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold text-gray-800 mb-3">Datos del lote registrado</h4>
          {[["Empresa", formData.empresa],["Producto", formData.sector],["Municipio", formData.municipio],["Fecha", lote.fecha],["Peso", lote.peso || "—"],["Proceso", lote.proceso],["Calidad", lote.calidad]].map(([k, v]) => (
            <div key={k} className="flex justify-between text-xs py-1 border-b border-gray-200 last:border-0">
              <span className="text-gray-400 flex-shrink-0 mr-2">{k}</span>
              <span className="text-gray-700 font-medium text-right truncate">{v}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-teal-50 rounded-lg p-3 mb-5">
        <p className="text-xs text-teal-700 leading-relaxed">El comprador internacional escanea este QR para verificar el origen, proceso y calidad del lote antes de confirmar la compra. Cada QR es único e irrepetible.</p>
      </div>

      <button onClick={onNext} className="w-full py-3 bg-teal-600 text-white rounded-xl font-medium hover:bg-teal-700">
        Generar documentos de exportación
      </button>
    </div>
  );
}

// ── STEP 5: DOCS + MATCH ──────────────────────────────────────────────────────

function Step5({ formData }) {
  const [country, setCountry] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("docs");

  const generate = async (c) => {
    setCountry(c);
    setLoading(true);
    setData(null);
    try {
      const r = await callClaude([{ role: "user", content: `Documentación de exportación y análisis de mercado:
Empresa: ${formData.empresa} | Producto: ${formData.sector} - ${formData.producto}
Origen: ${formData.municipio}, Santander, Colombia | Destino: ${c}

{"documentos":[{"nombre":"Certificado de Origen","estado":"requerido","descripcion":"breve descripción","entidad":"quién lo emite en Colombia"},{"nombre":"Factura Comercial Pro Forma","estado":"requerido","descripcion":"...","entidad":"..."},{"nombre":"Lista de Empaque","estado":"requerido","descripcion":"...","entidad":"..."},{"nombre":"Certificado Fitosanitario","estado":"requerido u opcional","descripcion":"...","entidad":"ICA Colombia"},{"nombre":"Registro/Notificación Sanitaria ${c}","estado":"requerido","descripcion":"...","entidad":"autoridad de ${c}"}],"requisitos":["requisito específico 1 para ${c}","requisito 2","requisito 3"],"tiempoEstimado":"X-Y semanas","mercados":[{"pais":"${c}","demanda":"Alta|Media|Baja","precio":"precio por kg o ton en USD","tendencia":"Creciendo|Estable|Decreciendo","nota":"insight clave para este mercado"},{"pais":"segundo país recomendado","demanda":"...","precio":"...","tendencia":"...","nota":"..."},{"pais":"tercer país recomendado","demanda":"...","precio":"...","tendencia":"...","nota":"..."}]}` }]);
      setData(r);
    } catch {
      setData({ documentos: [{ nombre: "Certificado de Origen", estado: "requerido", descripcion: "Acredita que el producto fue producido en Colombia", entidad: "Cámara de Comercio" }, { nombre: "Factura Comercial Pro Forma", estado: "requerido", descripcion: "Documento de oferta comercial con precios y condiciones de venta", entidad: "La empresa" }, { nombre: "Lista de Empaque", estado: "requerido", descripcion: "Detalle completo de bultos, pesos y dimensiones del envío", entidad: "La empresa" }, { nombre: "Certificado Fitosanitario", estado: "requerido", descripcion: "Autorización sanitaria del ICA para exportar productos agrícolas", entidad: "ICA Colombia" }, { nombre: `Registro Sanitario ${c}`, estado: "requerido", descripcion: `Aprobación de las autoridades sanitarias de ${c} para comercializar el producto`, entidad: `Autoridad sanitaria ${c}` }], requisitos: [`Etiquetar en el idioma oficial de ${c} con información nutricional`, "Clasificar correctamente con código arancelario SA para el producto", "Cumplir normas de empaque sostenible exigidas por mercado destino"], tiempoEstimado: "4-8 semanas", mercados: [{ pais: c, demanda: "Alta", precio: "USD 4.500-6.000/ton", tendencia: "Creciendo", nota: "Mercado con alta demanda de productos de origen verificado y comercio justo" }, { pais: "Países Bajos", demanda: "Alta", precio: "USD 5.000-6.500/ton", tendencia: "Estable", nota: "Principal puerto de entrada a Europa, hub de redistribución clave" }, { pais: "Japón", demanda: "Media", precio: "USD 6.000-8.500/ton", tendencia: "Creciendo", nota: "Paga prima diferencial por calidad y trazabilidad de origen" }] });
    }
    setLoading(false);
  };

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-1">Documentos + Match de mercados</h2>
      <p className="text-sm text-gray-500 mb-5">Selecciona el país de destino para generar documentación requerida y análisis de mercado con IA.</p>

      <div className="mb-5">
        <label className="block text-sm font-medium text-gray-700 mb-2">País de destino</label>
        <div className="flex flex-wrap gap-2">
          {PAISES.map(p => (
            <button key={p} onClick={() => generate(p)} className={`px-3 py-2 rounded-lg text-sm border transition-colors ${country === p ? "bg-teal-600 text-white border-teal-600" : "border-gray-200 text-gray-600 hover:border-teal-300"}`}>{p}</button>
          ))}
        </div>
      </div>

      {loading && (
        <div className="text-center py-12">
          <div className="w-10 h-10 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-gray-600 text-sm">Analizando mercado de {country} y generando documentos...</p>
        </div>
      )}

      {!country && !loading && (
        <div className="text-center py-12">
          <div className="w-14 h-14 rounded-full border border-gray-200 flex items-center justify-center mx-auto mb-3">
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <circle cx="14" cy="14" r="11" stroke="#d1d5db" strokeWidth="1.5"/>
              <path d="M3 14h22M14 3a18 18 0 000 22M14 3a18 18 0 010 22" stroke="#d1d5db" strokeWidth="1.5"/>
            </svg>
          </div>
          <p className="text-sm text-gray-400">Selecciona un país para comenzar</p>
        </div>
      )}

      {data && !loading && (
        <>
          <div className="flex gap-2 mb-4">
            {[["docs","Documentos requeridos"],["match","Match de mercados"]].map(([k, l]) => (
              <button key={k} onClick={() => setTab(k)} className={`px-4 py-2 rounded-lg text-sm font-medium border transition-colors ${tab === k ? "bg-teal-600 text-white border-teal-600" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}>{l}</button>
            ))}
          </div>

          {tab === "docs" && (
            <div>
              <div className="bg-amber-50 border border-amber-100 rounded-lg px-4 py-2.5 mb-4 flex items-center gap-2">
                <span className="text-amber-600 text-sm font-medium">Tiempo estimado:</span>
                <span className="text-amber-800 text-sm font-semibold">{data.tiempoEstimado}</span>
              </div>
              <div className="space-y-2.5 mb-4">
                {data.documentos?.map((doc, i) => (
                  <div key={i} className="bg-white border border-gray-100 rounded-xl p-4 flex items-start gap-3">
                    <div className="w-2 h-2 rounded-full bg-red-400 mt-1.5 flex-shrink-0"></div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <span className="text-sm font-medium text-gray-800">{doc.nombre}</span>
                        <span className="text-xs bg-red-50 text-red-600 px-2 py-0.5 rounded-full flex-shrink-0">{doc.estado}</span>
                      </div>
                      <p className="text-xs text-gray-500 mb-0.5">{doc.descripcion}</p>
                      <p className="text-xs text-teal-600">Emite: {doc.entidad}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="bg-teal-50 rounded-xl p-4">
                <h4 className="text-sm font-semibold text-teal-800 mb-2">Requisitos clave para {country}</h4>
                {data.requisitos?.map((r, i) => (
                  <div key={i} className="flex items-start gap-2 mb-1.5 last:mb-0">
                    <span className="text-teal-500 text-xs mt-0.5 flex-shrink-0">›</span>
                    <span className="text-xs text-teal-700 leading-relaxed">{r}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "match" && (
            <div className="space-y-3">
              {data.mercados?.map((m, i) => (
                <div key={i} className={`bg-white rounded-xl p-4 border ${i === 0 ? "border-teal-300" : "border-gray-100"}`}>
                  {i === 0 && <div className="text-xs text-teal-600 font-semibold mb-1.5">Tu destino seleccionado</div>}
                  <div className="flex items-center justify-between mb-2.5">
                    <h4 className="font-semibold text-gray-900">{m.pais}</h4>
                    <div className="flex gap-1.5">
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${m.demanda === "Alta" ? "bg-teal-100 text-teal-700" : m.demanda === "Media" ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-600"}`}>Demanda {m.demanda}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${m.tendencia === "Creciendo" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>{m.tendencia}</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <div className="text-xs text-gray-400">Precio estimado</div>
                      <div className="text-sm font-semibold text-gray-900">{m.precio}</div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-gray-400">Nota clave</div>
                      <div className="text-xs text-gray-600 leading-relaxed">{m.nota}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── MAIN APP ──────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState("landing");
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({ empresa: "", sector: "", municipio: "", producto: "", volumen: "", anos: "", certificaciones: "", experiencia: "No, nunca" });
  const [scoreData, setScoreData] = useState(null);
  const [profileData, setProfileData] = useState(null);

  const restart = () => { setView("landing"); setStep(1); setScoreData(null); setProfileData(null); };

  if (view === "landing") return <Landing onStart={() => setView("flow")} />;

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-2 cursor-pointer" onClick={restart}>
          <div className="w-7 h-7 bg-teal-600 rounded-lg flex items-center justify-center">
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
              <circle cx="7.5" cy="7.5" r="6" stroke="white" strokeWidth="1.5"/>
              <circle cx="7.5" cy="7.5" r="1.8" fill="white"/>
            </svg>
          </div>
          <span className="font-semibold text-gray-900 text-sm">OrigenIA</span>
        </div>
        <span className="text-xs text-gray-400">Paso {step} de {STEPS.length}</span>
      </nav>

      <div className="max-w-2xl mx-auto px-4 py-8">
        <StepBar current={step} />
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm">
          {step === 1 && <Step1 formData={formData} setFormData={setFormData} onNext={() => setStep(2)} />}
          {step === 2 && <Step2 formData={formData} scoreData={scoreData} setScoreData={setScoreData} onNext={() => setStep(3)} />}
          {step === 3 && <Step3 formData={formData} profileData={profileData} setProfileData={setProfileData} onNext={() => setStep(4)} />}
          {step === 4 && <Step4 formData={formData} onNext={() => setStep(5)} />}
          {step === 5 && <Step5 formData={formData} />}
        </div>
        {step > 1 && (
          <button onClick={() => setStep(s => s - 1)} className="mt-4 text-sm text-gray-400 hover:text-gray-600">
            Paso anterior
          </button>
        )}
      </div>
    </div>
  );
}