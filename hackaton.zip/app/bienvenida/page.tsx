'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function BienvenidaPage() {
  const [loadingPhase, setLoadingPhase] = useState(0) // 0: initial, 1: logo pulse, 2: text reveal, 3: content
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [activeFeature, setActiveFeature] = useState(0)
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; delay: number; size: number }>>([])

  // Generate floating particles
  useEffect(() => {
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 3,
      size: Math.random() * 4 + 2
    }))
    setParticles(newParticles)
  }, [])

  // Loading animation sequence
  useEffect(() => {
    // Smooth progress animation
    const progressInterval = setInterval(() => {
      setLoadingProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval)
          return 100
        }
        // Easing function for smoother progress
        const remaining = 100 - prev
        const increment = Math.max(0.5, remaining * 0.03)
        return Math.min(100, prev + increment)
      })
    }, 30)

    // Phase transitions with staggered timing
    const phase1Timer = setTimeout(() => setLoadingPhase(1), 800)   // Logo appears
    const phase2Timer = setTimeout(() => setLoadingPhase(2), 2000)  // Text reveals
    const phase3Timer = setTimeout(() => setLoadingPhase(3), 3200)  // Full content

    return () => {
      clearInterval(progressInterval)
      clearTimeout(phase1Timer)
      clearTimeout(phase2Timer)
      clearTimeout(phase3Timer)
    }
  }, [])

  // Features carousel
  useEffect(() => {
    if (loadingPhase < 3) return
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % 4)
    }, 3000)
    return () => clearInterval(interval)
  }, [loadingPhase])

  const features = [
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"/>
          <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
          <path d="M2 12h20"/>
        </svg>
      ),
      title: 'Comercio Global',
      description: 'Conecta productores colombianos con compradores internacionales'
    },
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2L2 7l10 5 10-5-10-5z"/>
          <path d="M2 17l10 5 10-5"/>
          <path d="M2 12l10 5 10-5"/>
        </svg>
      ),
      title: 'Trazabilidad QR',
      description: 'Cada producto con origen verificado y certificado'
    },
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
          <circle cx="12" cy="12" r="4"/>
        </svg>
      ),
      title: 'IA Exportadora',
      description: 'Inteligencia artificial para optimizar tus exportaciones'
    },
    {
      icon: (
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
          <polyline points="14 2 14 8 20 8"/>
          <path d="m9 15 2 2 4-4"/>
        </svg>
      ),
      title: 'Documentos Listos',
      description: 'Genera automaticamente toda la documentacion necesaria'
    }
  ]

  // Loading Screen
  if (loadingPhase < 3) {
    return (
      <div className="min-h-screen bg-background overflow-hidden relative">
        {/* Animated gradient background */}
        <div className="fixed inset-0 bg-gradient-to-br from-primary/5 via-background to-accent/5" />
        
        {/* Floating particles */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          {particles.map((particle) => (
            <div
              key={particle.id}
              className="absolute rounded-full bg-primary/20 animate-float"
              style={{
                left: `${particle.x}%`,
                top: `${particle.y}%`,
                width: `${particle.size}px`,
                height: `${particle.size}px`,
                animationDelay: `${particle.delay}s`,
                animationDuration: `${4 + particle.delay}s`
              }}
            />
          ))}
        </div>

        {/* Glowing orbs */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <div 
            className="absolute top-1/4 -left-20 w-80 h-80 bg-primary/30 rounded-full blur-[100px] animate-pulse"
            style={{ animationDuration: '3s' }}
          />
          <div 
            className="absolute bottom-1/4 -right-20 w-80 h-80 bg-accent/25 rounded-full blur-[100px] animate-pulse"
            style={{ animationDuration: '4s', animationDelay: '1s' }}
          />
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px]"
          />
        </div>

        {/* Main loading content */}
        <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6">
          
          {/* Orbiting rings */}
          <div className="relative">
            {/* Outer ring */}
            <div className={`absolute -inset-16 transition-all duration-1000 ${
              loadingPhase >= 1 ? 'opacity-0 scale-150' : 'opacity-100 scale-100'
            }`}>
              <div className="w-full h-full rounded-full border border-primary/20 animate-spin" style={{ animationDuration: '8s' }}>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-primary rounded-full shadow-lg shadow-primary/50" />
              </div>
            </div>
            
            {/* Middle ring */}
            <div className={`absolute -inset-10 transition-all duration-1000 ${
              loadingPhase >= 1 ? 'opacity-0 scale-125' : 'opacity-100 scale-100'
            }`}>
              <div className="w-full h-full rounded-full border-2 border-primary/30 animate-spin" style={{ animationDuration: '5s', animationDirection: 'reverse' }}>
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-2 h-2 bg-accent rounded-full shadow-lg shadow-accent/50" />
              </div>
            </div>

            {/* Inner pulsing ring */}
            <div className={`absolute -inset-6 transition-all duration-700 ${
              loadingPhase >= 1 ? 'opacity-0' : 'opacity-100'
            }`}>
              <div className="w-full h-full rounded-full border-2 border-primary/40 animate-ping" style={{ animationDuration: '1.5s' }} />
            </div>

            {/* Logo container */}
            <div className={`relative transition-all duration-1000 ease-out ${
              loadingPhase >= 1 ? 'scale-100' : 'scale-90'
            }`}>
              <div className={`w-28 h-28 bg-gradient-to-br from-primary to-primary/80 rounded-3xl flex items-center justify-center shadow-2xl transition-all duration-700 ${
                loadingPhase >= 1 ? 'shadow-primary/50 rotate-0' : 'shadow-primary/30 rotate-6'
              }`}>
                {/* Inner glow */}
                <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/20 to-transparent" />
                
                {/* Logo SVG */}
                <svg 
                  width="56" 
                  height="56" 
                  viewBox="0 0 18 18" 
                  fill="none" 
                  className={`relative z-10 transition-all duration-700 ${
                    loadingPhase >= 1 ? 'scale-100 opacity-100' : 'scale-75 opacity-70'
                  }`}
                >
                  <circle cx="9" cy="9" r="7" stroke="white" strokeWidth="1.5"/>
                  <circle cx="9" cy="9" r="2" fill="white"/>
                  <line x1="9" y1="2" x2="9" y2="5.5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  <line x1="9" y1="12.5" x2="9" y2="16" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  <line x1="2" y1="9" x2="5.5" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                  <line x1="12.5" y1="9" x2="16" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </div>
            </div>
          </div>

          {/* Brand name with letter animation */}
          <div className={`mt-10 overflow-hidden transition-all duration-700 ${
            loadingPhase >= 1 ? 'opacity-100' : 'opacity-0'
          }`}>
            <h1 className="text-5xl font-bold text-foreground tracking-tight flex">
              {'OrigenIA'.split('').map((letter, index) => (
                <span
                  key={index}
                  className={`inline-block transition-all duration-500 ${
                    loadingPhase >= 2 
                      ? 'translate-y-0 opacity-100' 
                      : 'translate-y-8 opacity-0'
                  }`}
                  style={{ transitionDelay: `${index * 60}ms` }}
                >
                  {letter}
                </span>
              ))}
            </h1>
          </div>

          {/* Tagline */}
          <div className={`mt-4 transition-all duration-700 delay-500 ${
            loadingPhase >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}>
            <p className="text-lg text-muted-foreground">Plataforma de Exportacion Inteligente</p>
          </div>

          {/* Progress bar */}
          <div className={`mt-12 w-72 transition-all duration-500 ${
            loadingPhase >= 2 ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
          }`}>
            <div className="h-1 bg-muted/50 rounded-full overflow-hidden backdrop-blur-sm">
              <div 
                className="h-full bg-gradient-to-r from-primary via-accent to-primary rounded-full transition-all duration-150 ease-out relative"
                style={{ width: `${loadingProgress}%` }}
              >
                {/* Shimmer effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
              </div>
            </div>
            
            {/* Loading text */}
            <div className="flex items-center justify-center gap-2 mt-4">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <p className="text-sm text-muted-foreground ml-2">
                {loadingProgress < 25 && 'Iniciando OrigenIA...'}
                {loadingProgress >= 25 && loadingProgress < 50 && 'Conectando servicios...'}
                {loadingProgress >= 50 && loadingProgress < 75 && 'Preparando plataforma...'}
                {loadingProgress >= 75 && loadingProgress < 100 && 'Casi listo...'}
                {loadingProgress >= 100 && 'Bienvenido'}
              </p>
            </div>
          </div>

          {/* Entering message */}
          <div className={`absolute bottom-12 transition-all duration-700 ${
            loadingPhase >= 2 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}>
            <div className="flex items-center gap-3 text-muted-foreground">
              <div className="w-8 h-[1px] bg-gradient-to-r from-transparent to-muted-foreground/50" />
              <span className="text-sm">Hecho en Colombia con orgullo</span>
              <div className="w-8 h-[1px] bg-gradient-to-l from-transparent to-muted-foreground/50" />
            </div>
          </div>
        </div>

        {/* Custom styles */}
        <style jsx>{`
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); opacity: 0.4; }
            50% { transform: translateY(-20px) rotate(180deg); opacity: 0.8; }
          }
          @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
          }
          .animate-float {
            animation: float 4s ease-in-out infinite;
          }
          .animate-shimmer {
            animation: shimmer 1.5s ease-in-out infinite;
          }
        `}</style>
      </div>
    )
  }

  // Main content after loading
  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-12">
        {/* Logo */}
        <div className="mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-gradient-to-br from-primary to-primary/80 rounded-2xl flex items-center justify-center shadow-lg shadow-primary/30">
              <svg width="28" height="28" viewBox="0 0 18 18" fill="none">
                <circle cx="9" cy="9" r="7" stroke="white" strokeWidth="1.5"/>
                <circle cx="9" cy="9" r="2" fill="white"/>
                <line x1="9" y1="2" x2="9" y2="5.5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="9" y1="12.5" x2="9" y2="16" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="2" y1="9" x2="5.5" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="12.5" y1="9" x2="16" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <span className="text-3xl font-bold text-foreground">OrigenIA</span>
          </div>
        </div>

        {/* Main Content */}
        <div className="text-center max-w-2xl animate-in fade-in slide-in-from-bottom-4 duration-700 delay-150">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm px-4 py-2 rounded-full mb-6 border border-primary/20">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            Hecho en Colombia - Exportado al mundo
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 leading-tight text-balance">
            Bienvenido a la plataforma de{' '}
            <span className="text-primary">exportacion inteligente</span>
          </h1>

          <p className="text-lg text-muted-foreground mb-10 leading-relaxed max-w-xl mx-auto text-pretty">
            Conectamos comerciantes colombianos con compradores internacionales. 
            Verifica el origen, genera documentos y exporta con confianza.
          </p>
        </div>

        {/* Features Carousel */}
        <div className="w-full max-w-3xl mb-12 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-300">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`group relative p-5 rounded-2xl border-2 transition-all duration-500 cursor-pointer ${
                  activeFeature === index
                    ? 'border-primary bg-primary/10 shadow-lg shadow-primary/10 scale-105'
                    : 'border-border bg-card hover:border-primary/40 hover:bg-muted/50'
                }`}
                onClick={() => setActiveFeature(index)}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 transition-all duration-300 ${
                  activeFeature === index
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground group-hover:bg-primary/20 group-hover:text-primary'
                }`}>
                  {feature.icon}
                </div>
                <h3 className={`font-semibold text-sm mb-1 transition-colors duration-300 ${
                  activeFeature === index ? 'text-primary' : 'text-foreground'
                }`}>
                  {feature.title}
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>

                {/* Progress indicator */}
                {activeFeature === index && (
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-primary/20 rounded-b-2xl overflow-hidden">
                    <div className="h-full bg-primary animate-progress" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-4 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-500">
          <Link
            href="/registro"
            className="group relative w-full sm:w-auto px-8 py-4 bg-primary text-primary-foreground rounded-xl font-semibold text-base shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 transition-all duration-300 hover:scale-105 overflow-hidden"
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              Comenzar ahora
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform duration-300 group-hover:translate-x-1">
                <path d="M5 12h14"/>
                <path d="m12 5 7 7-7 7"/>
              </svg>
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_100%] opacity-0 group-hover:opacity-30 transition-opacity duration-300 animate-shimmer-bg" />
          </Link>

          <Link
            href="/login"
            className="group w-full sm:w-auto px-8 py-4 bg-card text-foreground rounded-xl font-semibold text-base border-2 border-border hover:border-primary/50 hover:bg-muted/50 transition-all duration-300 flex items-center justify-center gap-2"
          >
            Ya tengo cuenta
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform duration-300 group-hover:translate-x-1">
              <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
              <polyline points="10 17 15 12 10 7"/>
              <line x1="15" y1="12" x2="3" y2="12"/>
            </svg>
          </Link>
        </div>

        {/* Trust badges */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-6 text-muted-foreground text-sm animate-in fade-in duration-700 delay-700">
          <div className="flex items-center gap-2">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <path d="m9 12 2 2 4-4"/>
            </svg>
            Datos protegidos
          </div>
          <div className="flex items-center gap-2">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"/>
              <path d="m9 12 2 2 4-4"/>
            </svg>
            100% Gratuito
          </div>
          <div className="flex items-center gap-2">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2v4"/>
              <path d="m4.93 4.93 2.83 2.83"/>
              <path d="M2 12h4"/>
              <path d="m4.93 19.07 2.83-2.83"/>
              <path d="M12 18v4"/>
              <path d="m19.07 19.07-2.83-2.83"/>
              <path d="M18 12h4"/>
              <path d="m19.07 4.93-2.83 2.83"/>
            </svg>
            5 min para empezar
          </div>
        </div>
      </div>

      {/* Custom animations */}
      <style jsx>{`
        @keyframes progress {
          from { width: 0%; }
          to { width: 100%; }
        }
        @keyframes shimmer-bg {
          from { background-position: 200% 0; }
          to { background-position: -200% 0; }
        }
        .animate-progress {
          animation: progress 3s linear infinite;
        }
        .animate-shimmer-bg {
          animation: shimmer-bg 2s linear infinite;
        }
      `}</style>
    </div>
  )
}
