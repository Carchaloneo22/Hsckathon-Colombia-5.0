'use client';

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

async function callClaude(messages: { role: string; content: string }[]) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: "Eres experto en exportaciones colombianas y comercio internacional. Responde ÚNICAMENTE con JSON válido, sin markdown, sin texto adicional.",
      messages,
    }),
  });
  const data = await res.json();
  const text = data.content?.find((b: { type: string; text?: string }) => b.type === "text")?.text || "{}";
  return JSON.parse(text.replace(/```json|```/g, "").trim());
}

const STEPS = [
  { id: 1, label: "Empresa" },
  { id: 2, label: "Score IA" },
  { id: 3, label: "Perfil" },
  { id: 4, label: "QR Lote" },
  { id: 5, label: "Documentos" },
];

const SECTORES = ["Cacao fino de aroma","Joyeria artesanal","Calzado","Manufactura","Citricos","Otro"];
const MUNICIPIOS = ["Bucaramanga","San Vicente de Chucuri","El Carmen de Chucuri","Landazuri","Lebrija","Giron","Piedecuesta","Barrancabermeja","Otro"];
const PAISES = ["Alemania","Estados Unidos","Francia","Paises Bajos","Japon","Reino Unido","Espana","Canada","Italia","Belgica"];

interface FormData {
  empresa: string;
  sector: string;
  municipio: string;
  producto: string;
  volumen: string;
  anos: string;
  certificaciones: string;
  experiencia: string;
}

interface ScoreData {
  score: number;
  nivel: string;
  resumen: string;
  fortalezas: string[];
  brechas: string[];
  acciones: string[];
  dimensiones: Record<string, number>;
}

interface ProfileData {
  es: { titulo: string; descripcion: string; ficha: Record<string, string>; historia: string };
  en: { titulo: string; descripcion: string; ficha: Record<string, string>; historia: string };
  de: { titulo: string; descripcion: string; ficha: Record<string, string>; historia: string };
}

// ── STEP BAR ─────────────────────────────────────────────────────────────────

function StepBar({ current }: { current: number }) {
  return (
    <div className="flex items-center justify-between mb-8">
      {STEPS.map((s, i) => (
        <div key={s.id} className="flex items-center">
          <div className="flex items-center gap-1.5">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold border-2 transition-colors ${s.id < current ? "bg-primary border-primary text-primary-foreground" : s.id === current ? "border-primary text-primary bg-background" : "border-border text-muted-foreground bg-background"}`}>
              {s.id < current ? "✓" : s.id}
            </div>
            <span className={`text-xs hidden sm:block ${s.id <= current ? "text-primary font-medium" : "text-muted-foreground"}`}>{s.label}</span>
          </div>
          {i < STEPS.length - 1 && (
            <div className={`h-px mx-2 sm:mx-3 w-8 sm:w-10 ${s.id < current ? "bg-primary" : "bg-border"}`}></div>
          )}
        </div>
      ))}
    </div>
  );
}

// ── STEP 1: FORM ──────────────────────────────────────────────────────────────

function Step1({ formData, setFormData, onNext }: { formData: FormData; setFormData: React.Dispatch<React.SetStateAction<FormData>>; onNext: () => void }) {
  const ok = formData.empresa && formData.sector && formData.municipio && formData.producto;
  const set = (k: keyof FormData, v: string) => setFormData(prev => ({ ...prev, [k]: v }));

  return (
    <div>
      <h2 className="text-xl font-semibold text-foreground mb-1">Cuentanos sobre tu empresa</h2>
      <p className="text-sm text-muted-foreground mb-6">La IA usara esta informacion para evaluar tu potencial exportador.</p>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Nombre de la empresa *</label>
          <input value={formData.empresa} onChange={e => set("empresa", e.target.value)} placeholder="Ej. Cacao del Oriente SAS" className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-background text-foreground" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Sector *</label>
            <select value={formData.sector} onChange={e => set("sector", e.target.value)} className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-background text-foreground">
              <option value="">Seleccionar...</option>
              {SECTORES.map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Municipio *</label>
            <select value={formData.municipio} onChange={e => set("municipio", e.target.value)} className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-background text-foreground">
              <option value="">Seleccionar...</option>
              {MUNICIPIOS.map(m => <option key={m}>{m}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Descripcion del producto principal *</label>
          <textarea value={formData.producto} onChange={e => set("producto", e.target.value)} placeholder="Ej. Cacao fino de aroma, variedad Criollo, fermentacion artesanal 5 dias, secado solar..." rows={3} className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary resize-none bg-background text-foreground" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Volumen mensual disponible</label>
            <input value={formData.volumen} onChange={e => set("volumen", e.target.value)} placeholder="Ej. 2 toneladas/mes" className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-background text-foreground" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1">Anos en operacion</label>
            <input value={formData.anos} onChange={e => set("anos", e.target.value)} placeholder="Ej. 5" className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-background text-foreground" />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">Certificaciones actuales</label>
          <input value={formData.certificaciones} onChange={e => set("certificaciones", e.target.value)} placeholder="Ej. Organico, UTZ, Rainforest Alliance, o Ninguna" className="w-full border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary bg-background text-foreground" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Experiencia exportadora</label>
          <div className="flex gap-2">
            {["No, nunca", "En proceso", "Si, tengo experiencia"].map(o => (
              <button key={o} onClick={() => set("experiencia", o)} className={`flex-1 py-2 px-2 rounded-lg text-xs border transition-colors ${formData.experiencia === o ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:border-primary/50"}`}>{o}</button>
            ))}
          </div>
        </div>
      </div>

      <button onClick={onNext} disabled={!ok} className={`mt-6 w-full py-3 rounded-xl font-medium text-sm transition-colors ${ok ? "bg-primary text-primary-foreground hover:bg-primary/90" : "bg-muted text-muted-foreground cursor-not-allowed"}`}>
        Evaluar mi empresa con IA
      </button>
    </div>
  );
}

// ── STEP 2: SCORE ─────────────────────────────────────────────────────────────

function Step2({ formData, scoreData, setScoreData, onNext }: { formData: FormData; scoreData: ScoreData | null; setScoreData: React.Dispatch<React.SetStateAction<ScoreData | null>>; onNext: () => void }) {
  const [loading, setLoading] = useState(!scoreData);

  useEffect(() => {
    if (scoreData) return;
    callClaude([{ role: "user", content: `Analiza esta MIPYME de Santander y devuelve este JSON exacto:
Empresa: ${formData.empresa} | Sector: ${formData.sector} | Municipio: ${formData.municipio}
Producto: ${formData.producto} | Volumen: ${formData.volumen} | Anos: ${formData.anos}
Certificaciones: ${formData.certificaciones} | Experiencia: ${formData.experiencia}

{"score":numero_0_100,"nivel":"Inicial|En desarrollo|Avanzado|Listo para exportar","resumen":"2 oraciones sobre potencial exportador","fortalezas":["f1","f2","f3"],"brechas":["b1","b2","b3"],"acciones":["accion1","accion2","accion3"],"dimensiones":{"producto":numero,"documentacion":numero,"mercado":numero,"capacidad":numero}}` }])
      .then(r => { setScoreData(r); setLoading(false); })
      .catch(() => {
        setScoreData({ score: 64, nivel: "En desarrollo", resumen: "Tu empresa tiene un producto con potencial exportador real en mercados europeos y asiaticos. Con certificaciones internacionales y documentacion adecuada, podrias estar exportando en 6-12 meses.", fortalezas: ["Producto diferenciado con caracteristicas unicas de origen", "Ubicacion estrategica en Santander, epicentro cacaotero", "Experiencia productiva consolidada"], brechas: ["Ausencia de certificaciones internacionales reconocidas", "Sin perfil digital en idiomas extranjeros", "Documentacion exportadora inexistente"], acciones: ["Iniciar proceso de certificacion Rainforest Alliance o UTZ", "Crear ficha tecnica del producto en ingles y aleman", "Contactar ProColombia para asesoria exportadora gratuita"], dimensiones: { producto: 75, documentacion: 30, mercado: 55, capacidad: 65 } });
        setLoading(false);
      });
  }, [formData, scoreData, setScoreData]);

  if (loading) return (
    <div className="text-center py-20">
      <div className="w-12 h-12 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
      <p className="text-foreground font-medium">Analizando tu empresa con IA...</p>
      <p className="text-muted-foreground text-sm mt-1">Calculando score exportador y plan de accion</p>
    </div>
  );

  const { score, nivel, resumen, fortalezas, brechas, acciones, dimensiones } = scoreData!;
  const scoreColor = score >= 70 ? "text-primary" : score >= 45 ? "text-warning" : "text-destructive";
  const levelBg = score >= 70 ? "bg-primary/10 text-primary" : score >= 45 ? "bg-warning/10 text-warning" : "bg-destructive/10 text-destructive";
  const dimLabels: Record<string, string> = { producto: "Producto", documentacion: "Documentacion", mercado: "Mercado", capacidad: "Capacidad" };
  const barColor = (v: number) => v >= 70 ? "bg-primary" : v >= 45 ? "bg-warning" : "bg-destructive";

  return (
    <div>
      <h2 className="text-xl font-semibold text-foreground mb-1">Score exportador</h2>
      <p className="text-sm text-muted-foreground mb-5">{formData.empresa} - {formData.sector}</p>

      <div className="bg-muted rounded-2xl p-6 mb-5 text-center">
        <div className={`text-7xl font-bold ${scoreColor} leading-none mb-1`}>{score}</div>
        <div className="text-muted-foreground text-sm mb-3">puntos de 100</div>
        <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${levelBg}`}>{nivel}</span>
        <p className="text-muted-foreground text-sm mt-4 leading-relaxed max-w-sm mx-auto">{resumen}</p>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-5">
        {Object.entries(dimensiones || {}).map(([k, v]) => (
          <div key={k} className="bg-card border border-border rounded-xl p-3">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-muted-foreground">{dimLabels[k] || k}</span>
              <span className="text-sm font-semibold text-foreground">{v}</span>
            </div>
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div className={`h-1.5 rounded-full ${barColor(v)}`} style={{ width: `${v}%` }}></div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-5">
        <div>
          <h4 className="text-sm font-semibold text-foreground mb-2">Fortalezas</h4>
          {fortalezas?.map((f, i) => (
            <div key={i} className="flex items-start gap-2 mb-2">
              <span className="text-primary mt-0.5 text-xs font-bold flex-shrink-0">✓</span>
              <span className="text-xs text-muted-foreground leading-relaxed">{f}</span>
            </div>
          ))}
        </div>
        <div>
          <h4 className="text-sm font-semibold text-foreground mb-2">Brechas a cerrar</h4>
          {brechas?.map((b, i) => (
            <div key={i} className="flex items-start gap-2 mb-2">
              <span className="text-warning mt-0.5 text-xs font-bold flex-shrink-0">!</span>
              <span className="text-xs text-muted-foreground leading-relaxed">{b}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-primary/10 rounded-xl p-4 mb-6">
        <h4 className="text-sm font-semibold text-primary mb-2">Plan de accion prioritario</h4>
        {acciones?.map((a, i) => (
          <div key={i} className="flex items-start gap-2 mb-2 last:mb-0">
            <span className="text-primary font-bold text-sm flex-shrink-0">{i + 1}.</span>
            <span className="text-sm text-primary/80 leading-relaxed">{a}</span>
          </div>
        ))}
      </div>

      <button onClick={onNext} className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90">
        Generar perfil internacional
      </button>
    </div>
  );
}

// ── MAIN DASHBOARD ────────────────────────────────────────────────────────────

export default function DashboardPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({ empresa: "", sector: "", municipio: "", producto: "", volumen: "", anos: "", certificaciones: "", experiencia: "No, nunca" });
  const [scoreData, setScoreData] = useState<ScoreData | null>(null);

  const handleLogout = () => {
    router.push('/bienvenida');
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="bg-card border-b border-border px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <Link href="/dashboard" className="flex items-center gap-2">
          <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center">
            <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
              <circle cx="7.5" cy="7.5" r="6" stroke="white" strokeWidth="1.5"/>
              <circle cx="7.5" cy="7.5" r="1.8" fill="white"/>
            </svg>
          </div>
          <span className="font-semibold text-foreground text-sm">OrigenIA</span>
        </Link>
        <div className="flex items-center gap-4">
          <span className="text-xs text-muted-foreground">Paso {step} de {STEPS.length}</span>
          <button onClick={handleLogout} className="text-xs text-primary hover:text-primary/80 font-medium flex items-center gap-1">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Cerrar sesion
          </button>
        </div>
      </nav>

      <div className="max-w-2xl mx-auto px-4 py-8">
        <StepBar current={step} />
        <div className="bg-card rounded-2xl border border-border p-6 shadow-sm">
          {step === 1 && <Step1 formData={formData} setFormData={setFormData} onNext={() => setStep(2)} />}
          {step === 2 && <Step2 formData={formData} scoreData={scoreData} setScoreData={setScoreData} onNext={() => setStep(3)} />}
        </div>
        {step > 1 && (
          <button onClick={() => setStep(s => s - 1)} className="mt-4 text-sm text-muted-foreground hover:text-foreground">
            Paso anterior
          </button>
        )}
      </div>
    </div>
  );
}
