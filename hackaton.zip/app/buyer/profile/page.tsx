'use client'

import { useState } from 'react'
import { BuyerLayout } from '@/components/buyer/buyer-layout'

const COUNTRY_REQUIREMENTS: Record<string, { req: string; done: boolean }[]> = {
  Alemania: [
    { req: 'Certificado orgánico EU 2018/848', done: true },
    { req: 'Trazabilidad completa documentada', done: true },
    { req: 'Análisis de residuos (máx. 0.01 mg/kg)', done: false },
    { req: 'Etiquetado en alemán / inglés', done: false },
    { req: 'Declaración aduanera EUR.1', done: true },
  ],
  'Estados Unidos': [
    { req: 'Registro FDA (Food Facility)', done: true },
    { req: 'FSMA Prior Notice', done: false },
    { req: 'Certificado fitosanitario ICA', done: true },
    { req: 'Etiquetado Nutrition Facts en inglés', done: false },
    { req: 'Bond aduanero', done: false },
  ],
  Japón: [
    { req: 'Certificado JAS (Organic Japan)', done: false },
    { req: 'Certificado fitosanitario ICA', done: true },
    { req: 'Análisis de pesticidas (200+ parámetros)', done: false },
    { req: 'Etiquetado en japonés', done: false },
    { req: 'Permiso de importación MAFF', done: false },
  ],
  Francia: [
    { req: 'Certificado AB (Agricultura Biológica)', done: false },
    { req: 'Trazabilidad completa (EU 178/2002)', done: true },
    { req: 'Análisis de contaminantes', done: false },
    { req: 'Registro importador DGCCRF', done: false },
    { req: 'Etiquetado en francés', done: false },
  ],
  'Países Bajos': [
    { req: 'Certificado orgánico EU', done: true },
    { req: 'Análisis de aflatoxinas', done: false },
    { req: 'Certificado fitosanitario ICA', done: true },
    { req: 'Etiquetado en neerlandés/inglés', done: false },
  ],
}

const SECTORS = ['Agro', 'Joyería', 'Calzado', 'Manufactura', 'Cítricos']
const COUNTRIES = Object.keys(COUNTRY_REQUIREMENTS)

export default function ProfilePage() {
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const [activeTab, setActiveTab] = useState<'info' | 'preferencias' | 'direcciones' | 'requisitos'>('info')
  const [destCountry, setDestCountry] = useState('Alemania')
  const [selectedSectors, setSelectedSectors] = useState(['Agro', 'Joyería'])
  const [saved, setSaved] = useState(false)

  const [form, setForm] = useState({
    nombre: 'Maria Gonzalez',
    empresa: 'Global Trade GmbH',
    pais: 'Alemania',
    industria: 'Importación de alimentos gourmet',
    licencia: 'DE-IMP-2024-00847',
    email: 'maria@globaltrade.de',
    phone: '+49 30 123 4567',
    volumen: '5,000 - 20,000 USD/pedido',
  })

  const t = (es: string, en: string) => lang === 'ES' ? es : en

  const toggleSector = (s: string) =>
    setSelectedSectors(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s])

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const requirements = COUNTRY_REQUIREMENTS[destCountry] || []
  const done = requirements.filter(r => r.done).length

  const TABS = [
    { id: 'info' as const,        label: t('Información', 'Info') },
    { id: 'preferencias' as const, label: t('Preferencias', 'Preferences') },
    { id: 'direcciones' as const,  label: t('Direcciones', 'Addresses') },
    { id: 'requisitos' as const,   label: t('Requisitos País', 'Country Req.') },
  ]

  return (
    <BuyerLayout activePage="profile" lang={lang} onLangChange={setLang}>
      <div className="max-w-2xl mx-auto space-y-5">

        {/* Profile Header */}
        <div className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-primary/80 rounded-2xl p-6 text-primary-foreground">
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute -top-8 -right-8 w-40 h-40 bg-white/5 rounded-full blur-2xl" />
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-white/5 rounded-full blur-xl" />
          </div>
          <div className="relative z-10 flex items-center gap-5">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-white font-bold text-2xl flex-none border border-white/20">
              MG
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold text-white">{form.nombre}</h1>
              <p className="text-sm text-primary-foreground/70">{form.empresa} · {form.pais}</p>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <span className="text-xs bg-white/15 text-white px-2.5 py-0.5 rounded-full border border-white/20 font-medium">
                  {t('Comprador Internacional', 'International Buyer')}
                </span>
                <span className="text-xs bg-green-400/20 text-green-300 border border-green-400/30 px-2.5 py-0.5 rounded-full font-medium flex items-center gap-1">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                  {t('Verificado', 'Verified')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-muted/50 rounded-xl p-1 border border-border overflow-x-auto">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-none px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-card text-foreground shadow-sm border border-border'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'info' && (
          <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
            <h2 className="text-base font-semibold text-foreground">{t('Información de la Empresa', 'Company Information')}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { label: t('Nombre completo', 'Full name'), key: 'nombre' as const },
                { label: t('Empresa', 'Company'), key: 'empresa' as const },
                { label: t('País', 'Country'), key: 'pais' as const },
                { label: t('Industria', 'Industry'), key: 'industria' as const },
                { label: t('Email', 'Email'), key: 'email' as const },
                { label: t('Teléfono', 'Phone'), key: 'phone' as const },
                { label: t('Licencia de importación', 'Import license'), key: 'licencia' as const },
                { label: t('Volumen típico', 'Typical volume'), key: 'volumen' as const },
              ].map(field => (
                <div key={field.key}>
                  <label className="block text-xs font-medium text-muted-foreground mb-1">{field.label}</label>
                  <input
                    value={form[field.key]}
                    onChange={e => setForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                    className="w-full border border-border rounded-xl px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary"
                  />
                </div>
              ))}
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button onClick={handleSave} className="px-5 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors">
                {t('Guardar cambios', 'Save changes')}
              </button>
              {saved && (
                <span className="flex items-center gap-1.5 text-sm text-green-700">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                  {t('Guardado', 'Saved')}
                </span>
              )}
            </div>
          </div>
        )}

        {activeTab === 'preferencias' && (
          <div className="bg-card rounded-2xl border border-border p-5 space-y-5">
            <h2 className="text-base font-semibold text-foreground">{t('Preferencias de Compra', 'Purchase Preferences')}</h2>

            <div>
              <label className="block text-sm font-medium text-foreground mb-3">{t('Sectores de interés', 'Sectors of interest')}</label>
              <div className="flex flex-wrap gap-2">
                {SECTORS.map(s => (
                  <button
                    key={s}
                    onClick={() => toggleSector(s)}
                    className={`px-4 py-2 rounded-xl text-sm border transition-all duration-150 ${
                      selectedSectors.includes(s)
                        ? 'bg-primary text-primary-foreground border-primary scale-105'
                        : 'bg-background text-muted-foreground border-border hover:border-primary/40'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">{t('Rango de precio objetivo (USD/pedido)', 'Target price range (USD/order)')}</label>
              <select className="w-full border border-border rounded-xl px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary">
                <option>$1,000 - $5,000 USD</option>
                <option>$5,000 - $20,000 USD</option>
                <option selected>$20,000 - $100,000 USD</option>
                <option>{'> $100,000 USD'}</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">{t('Frecuencia de compra', 'Purchase frequency')}</label>
              <div className="grid grid-cols-3 gap-2">
                {[t('Mensual', 'Monthly'), t('Trimestral', 'Quarterly'), t('Semestral', 'Biannual')].map(opt => (
                  <button key={opt} className={`py-2 px-3 text-sm border rounded-xl transition-colors ${opt === t('Trimestral', 'Quarterly') ? 'border-primary bg-primary/5 text-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-3">{t('Notificaciones', 'Notifications')}</label>
              <div className="space-y-3">
                {[
                  { label: t('Nuevas cotizaciones', 'New quotes'), checked: true },
                  { label: t('Actualizaciones de pedidos', 'Order updates'), checked: true },
                  { label: t('Nuevos productos en mi sector', 'New products in my sector'), checked: false },
                  { label: t('Alertas de precios', 'Price alerts'), checked: true },
                ].map((item, i) => (
                  <label key={i} className="flex items-center justify-between cursor-pointer group">
                    <span className="text-sm text-foreground">{item.label}</span>
                    <div className={`relative w-10 h-5 rounded-full transition-colors ${item.checked ? 'bg-primary' : 'bg-border'}`}>
                      <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${item.checked ? 'translate-x-5' : 'translate-x-0.5'}`} />
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <button onClick={handleSave} className="px-5 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors">
              {saved ? t('Guardado', 'Saved') : t('Guardar preferencias', 'Save preferences')}
            </button>
          </div>
        )}

        {activeTab === 'direcciones' && (
          <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-foreground">{t('Direcciones de Entrega', 'Delivery Addresses')}</h2>
              <button className="text-sm text-primary hover:underline font-medium flex items-center gap-1">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                {t('Agregar', 'Add')}
              </button>
            </div>
            {[
              { label: t('Principal', 'Main'), address: 'Hamburger Allee 45, 60486 Frankfurt am Main, Alemania', isMain: true },
              { label: t('Almacén', 'Warehouse'), address: 'Industriestrasse 12, 22761 Hamburgo, Alemania', isMain: false },
            ].map((addr, i) => (
              <div key={i} className={`p-4 rounded-xl border ${addr.isMain ? 'border-primary/30 bg-primary/5' : 'border-border'} flex items-start gap-3`}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary flex-none mt-0.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="text-sm font-semibold text-foreground">{addr.label}</p>
                    {addr.isMain && <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full border border-primary/20">{t('Principal', 'Main')}</span>}
                  </div>
                  <p className="text-xs text-muted-foreground">{addr.address}</p>
                </div>
                <button className="text-muted-foreground hover:text-foreground text-xs">{t('Editar', 'Edit')}</button>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'requisitos' && (
          <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div>
                <h2 className="text-base font-semibold text-foreground">{t('Requisitos de Importación', 'Import Requirements')}</h2>
                <p className="text-sm text-muted-foreground">{t('Checklist para tu país de destino', 'Checklist for your destination country')}</p>
              </div>
              <select
                value={destCountry}
                onChange={e => setDestCountry(e.target.value)}
                className="border border-border rounded-xl px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary"
              >
                {COUNTRIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>

            {/* Progress */}
            <div className="bg-muted/40 rounded-xl p-4 border border-border">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">{t('Progreso de cumplimiento', 'Compliance progress')}</span>
                <span className="text-sm font-bold text-primary">{done}/{requirements.length}</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${(done / requirements.length) * 100}%` }} />
              </div>
              <p className="text-xs text-muted-foreground mt-1.5">
                {done === requirements.length
                  ? t('Listo para importar a', 'Ready to import to')
                  : t('Pendiente cumplimiento para importar a', 'Pending compliance to import to')
                } {destCountry}
              </p>
            </div>

            {/* Requirements list */}
            <div className="space-y-2">
              {requirements.map((req, i) => (
                <div key={i} className={`flex items-start gap-3 p-3.5 rounded-xl border ${req.done ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'}`}>
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-none mt-0.5 ${req.done ? 'bg-green-500' : 'bg-amber-400'}`}>
                    {req.done ? (
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                    ) : (
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    )}
                  </div>
                  <p className={`text-sm flex-1 ${req.done ? 'text-green-800' : 'text-amber-900'}`}>{req.req}</p>
                  {!req.done && (
                    <button className="text-xs text-amber-700 hover:underline flex-none font-medium">{t('Gestionar', 'Manage')}</button>
                  )}
                </div>
              ))}
            </div>

            <button className="w-full flex items-center justify-center gap-2 py-2.5 border border-border rounded-xl text-sm text-foreground hover:bg-muted transition-colors">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              {t('Descargar checklist completo', 'Download complete checklist')}
            </button>
          </div>
        )}

      </div>
    </BuyerLayout>
  )
}
