'use client'

import { useState } from 'react'
import { BuyerLayout } from '@/components/buyer/buyer-layout'

type OrderStatus = 'Confirmado' | 'En producción' | 'En tránsito' | 'Aduana' | 'Entregado'

interface Order {
  id: string
  product: string
  producer: string
  origin: string
  sector: string
  qty: string
  total: string
  tracking: string
  estimatedDelivery: string
  status: OrderStatus
  timeline: { stage: string; date: string; done: boolean; note?: string }[]
}

const ORDERS: Order[] = [
  {
    id: 'ORD-2024-001',
    product: 'Panela Orgánica Pulverizada',
    producer: 'Trapiche Los Andes',
    origin: 'Suaita, Santander',
    sector: 'Agro',
    qty: '200 kg',
    total: '$290 USD',
    tracking: 'MSC-CG-2024-11847',
    estimatedDelivery: '28 Nov 2024',
    status: 'En tránsito',
    timeline: [
      { stage: 'Confirmado', date: '01 Nov 2024', done: true, note: 'Pago recibido y orden confirmada' },
      { stage: 'En producción', date: '05 Nov 2024', done: true, note: 'Producción iniciada, ETA 7 días' },
      { stage: 'Control de calidad', date: '10 Nov 2024', done: true, note: 'Análisis de laboratorio aprobado' },
      { stage: 'En tránsito', date: '15 Nov 2024', done: true, note: 'Contenedor embarcado en Barranquilla' },
      { stage: 'Aduana', date: 'Est. 25 Nov 2024', done: false },
      { stage: 'Entregado', date: 'Est. 28 Nov 2024', done: false },
    ],
  },
  {
    id: 'ORD-2024-002',
    product: 'Cacao Fino de Aroma',
    producer: 'Hacienda La Esmeralda',
    origin: 'San Vicente de Chucurí',
    sector: 'Agro',
    qty: '500 kg',
    total: '$1.450 USD',
    tracking: 'Pendiente asignación',
    estimatedDelivery: '10 Dic 2024',
    status: 'En producción',
    timeline: [
      { stage: 'Confirmado', date: '05 Nov 2024', done: true, note: 'Pedido confirmado tras cotización' },
      { stage: 'En producción', date: '08 Nov 2024', done: true, note: 'Lote SAN-AG-001 en proceso de fermentación' },
      { stage: 'Control de calidad', date: 'Est. 20 Nov 2024', done: false },
      { stage: 'En tránsito', date: 'Est. 25 Nov 2024', done: false },
      { stage: 'Aduana', date: 'Est. 05 Dic 2024', done: false },
      { stage: 'Entregado', date: 'Est. 10 Dic 2024', done: false },
    ],
  },
  {
    id: 'ORD-2024-003',
    product: 'Calzado de Cuero Premium',
    producer: 'Calzado El Pionero',
    origin: 'Bucaramanga',
    sector: 'Calzado',
    qty: '100 pares',
    total: '$5.500 USD',
    tracking: 'DHL-INT-887234',
    estimatedDelivery: '05 Dic 2024',
    status: 'Aduana',
    timeline: [
      { stage: 'Confirmado', date: '25 Oct 2024', done: true, note: 'Pedido confirmado' },
      { stage: 'En producción', date: '28 Oct 2024', done: true, note: 'Producción completada en 10 días' },
      { stage: 'Control de calidad', date: '08 Nov 2024', done: true, note: 'ISO 9001 verificado' },
      { stage: 'En tránsito', date: '12 Nov 2024', done: true, note: 'Cargado en vuelo BOG→FRA' },
      { stage: 'Aduana', date: '18 Nov 2024', done: true, note: 'En proceso de despacho aduanero en Frankfurt' },
      { stage: 'Entregado', date: 'Est. 05 Dic 2024', done: false },
    ],
  },
  {
    id: 'ORD-2023-089',
    product: 'Bocadillo Veleño Artesanal',
    producer: 'Dulces de Vélez',
    origin: 'Vélez, Santander',
    sector: 'Agro',
    qty: '150 kg',
    total: '$637 USD',
    tracking: 'FED-EX-987654',
    estimatedDelivery: '15 Oct 2024',
    status: 'Entregado',
    timeline: [
      { stage: 'Confirmado', date: '01 Sep 2024', done: true },
      { stage: 'En producción', date: '05 Sep 2024', done: true },
      { stage: 'Control de calidad', date: '12 Sep 2024', done: true },
      { stage: 'En tránsito', date: '18 Sep 2024', done: true },
      { stage: 'Aduana', date: '10 Oct 2024', done: true },
      { stage: 'Entregado', date: '15 Oct 2024', done: true, note: 'Entregado exitosamente en Berlin' },
    ],
  },
]

const COLUMNS: OrderStatus[] = ['Confirmado', 'En producción', 'En tránsito', 'Aduana', 'Entregado']

const COLUMN_STYLE: Record<OrderStatus, { header: string; dot: string }> = {
  Confirmado:      { header: 'bg-blue-50 border-blue-200 text-blue-800',    dot: 'bg-blue-500' },
  'En producción': { header: 'bg-amber-50 border-amber-200 text-amber-800', dot: 'bg-amber-500' },
  'En tránsito':   { header: 'bg-purple-50 border-purple-200 text-purple-800', dot: 'bg-purple-500' },
  Aduana:          { header: 'bg-orange-50 border-orange-200 text-orange-800', dot: 'bg-orange-500' },
  Entregado:       { header: 'bg-green-50 border-green-200 text-green-800',  dot: 'bg-green-500' },
}

const SECTOR_ICON: Record<string, string> = { Agro: '🌱', Joyería: '💎', Calzado: '👟', Cítricos: '🍋', Manufactura: '🏭' }

export default function OrdersPage() {
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)

  const t = (es: string, en: string) => lang === 'ES' ? es : en

  return (
    <BuyerLayout activePage="orders" lang={lang} onLangChange={setLang}>
      <div className="space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">{t('Seguimiento de Pedidos', 'Order Tracking')}</h1>
            <p className="text-sm text-muted-foreground">{t('Vista kanban de todos tus pedidos activos', 'Kanban view of all your active orders')}</p>
          </div>
          <div className="bg-primary/5 border border-primary/20 rounded-xl px-4 py-2 text-right flex-none">
            <p className="text-xs text-muted-foreground">{t('Valor total en curso', 'Total value in progress')}</p>
            <p className="text-lg font-bold text-primary">$7,877 USD</p>
          </div>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
          {COLUMNS.map(col => {
            const count = ORDERS.filter(o => o.status === col).length
            const style = COLUMN_STYLE[col]
            return (
              <div key={col} className={`rounded-xl px-3 py-2.5 border text-center ${style.header}`}>
                <p className="text-xl font-bold">{count}</p>
                <p className="text-xs font-medium leading-tight mt-0.5">{t(col, col)}</p>
              </div>
            )
          })}
        </div>

        {/* Kanban Board */}
        <div className="flex gap-4 overflow-x-auto pb-4" style={{ scrollbarWidth: 'thin', minWidth: 0 }}>
          {COLUMNS.map(col => {
            const colOrders = ORDERS.filter(o => o.status === col)
            const style = COLUMN_STYLE[col]
            return (
              <div key={col} className="flex-none w-64 bg-muted/40 rounded-2xl p-3 border border-border">
                {/* Column header */}
                <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border mb-3 ${style.header}`}>
                  <div className={`w-2 h-2 rounded-full ${style.dot}`} />
                  <span className="text-sm font-semibold flex-1">{t(col, col)}</span>
                  <span className="text-xs font-bold w-5 h-5 bg-white/70 rounded-full flex items-center justify-center">
                    {colOrders.length}
                  </span>
                </div>

                {/* Cards */}
                <div className="space-y-2">
                  {colOrders.length === 0 && (
                    <div className="text-center py-6 text-xs text-muted-foreground">
                      {t('Sin pedidos', 'No orders')}
                    </div>
                  )}
                  {colOrders.map(order => (
                    <div
                      key={order.id}
                      onClick={() => setSelectedOrder(order)}
                      className="bg-card rounded-xl border border-border p-3 hover:shadow-md hover:-translate-y-0.5 transition-all duration-150 cursor-pointer"
                    >
                      <div className="flex items-start gap-2 mb-2">
                        <span className="text-lg">{SECTOR_ICON[order.sector]}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-foreground leading-tight truncate">{order.product}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{order.producer}</p>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-muted-foreground">{t('Cantidad', 'Qty')}</span>
                          <span className="text-[10px] font-medium text-foreground">{order.qty}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-muted-foreground">{t('Total', 'Total')}</span>
                          <span className="text-[10px] font-bold text-primary">{order.total}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-muted-foreground">ETA</span>
                          <span className="text-[10px] font-medium text-foreground">{order.estimatedDelivery}</span>
                        </div>
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-2 border-t border-border pt-1.5 truncate">{order.id}</p>
                    </div>
                  ))}
                </div>
              </div>
            )
          })}
        </div>

        {/* List View (mobile-friendly) */}
        <div className="md:hidden space-y-3">
          <h2 className="text-base font-semibold text-foreground">{t('Lista de Pedidos', 'Orders List')}</h2>
          {ORDERS.map(order => {
            const style = COLUMN_STYLE[order.status]
            return (
              <div key={order.id} onClick={() => setSelectedOrder(order)} className="bg-card rounded-xl border border-border p-4 cursor-pointer hover:border-primary/30 transition-colors">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{order.product}</p>
                    <p className="text-xs text-muted-foreground">{order.producer}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full border font-medium flex-none ${style.header}`}>{order.status}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{order.qty}</span>
                  <span>·</span>
                  <span className="font-bold text-primary">{order.total}</span>
                  <span>·</span>
                  <span>ETA {order.estimatedDelivery}</span>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setSelectedOrder(null)} />
          <div className="relative bg-card rounded-2xl border border-border max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between p-5 border-b border-border">
              <div>
                <h3 className="text-base font-bold text-foreground">{selectedOrder.product}</h3>
                <p className="text-xs text-muted-foreground">{selectedOrder.id} · {selectedOrder.producer}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="text-muted-foreground hover:text-foreground ml-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="p-5 space-y-5">
              {/* Order details */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: t('Cantidad', 'Quantity'), value: selectedOrder.qty },
                  { label: t('Total', 'Total'), value: selectedOrder.total },
                  { label: t('N° de seguimiento', 'Tracking No.'), value: selectedOrder.tracking },
                  { label: t('Entrega estimada', 'Est. Delivery'), value: selectedOrder.estimatedDelivery },
                ].map((row, i) => (
                  <div key={i} className="bg-muted/40 rounded-xl p-3">
                    <p className="text-xs text-muted-foreground mb-0.5">{row.label}</p>
                    <p className="text-sm font-semibold text-foreground">{row.value}</p>
                  </div>
                ))}
              </div>

              {/* Timeline */}
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-3">{t('Seguimiento de envío', 'Shipment timeline')}</h4>
                <div className="relative">
                  <div className="absolute left-4 top-4 bottom-0 w-0.5 bg-border" />
                  <div className="space-y-3">
                    {selectedOrder.timeline.map((step, i) => (
                      <div key={i} className="flex gap-3 relative">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 flex-none border-2 ${
                          step.done ? 'bg-primary border-primary' : 'bg-muted border-border'
                        }`}>
                          {step.done ? (
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                          ) : (
                            <div className="w-2.5 h-2.5 rounded-full bg-muted-foreground/30" />
                          )}
                        </div>
                        <div className={`flex-1 pb-1 ${step.done ? 'opacity-100' : 'opacity-50'}`}>
                          <div className="flex items-center justify-between">
                            <p className={`text-sm font-medium ${step.done ? 'text-foreground' : 'text-muted-foreground'}`}>{step.stage}</p>
                            <p className="text-xs text-muted-foreground">{step.date}</p>
                          </div>
                          {step.note && <p className="text-xs text-muted-foreground mt-0.5">{step.note}</p>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Documents */}
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-3">{t('Documentos', 'Documents')}</h4>
                <div className="space-y-2">
                  {[t('Factura Comercial', 'Commercial Invoice'), t('Lista de Empaque', 'Packing List'), t('Certificado de Origen', 'Certificate of Origin')].map((doc, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 bg-muted/30 rounded-xl border border-border hover:border-primary/30 transition-colors cursor-pointer">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                      <span className="text-sm text-foreground flex-1">{doc}</span>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-muted-foreground"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </BuyerLayout>
  )
}
