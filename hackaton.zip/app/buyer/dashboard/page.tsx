'use client'

import { useState } from 'react'
import Link from 'next/link'
import { BuyerLayout } from '@/components/buyer/buyer-layout'

const RECOMMENDED_PRODUCTS = [
  { id: '1', name: 'Cacao Fino de Aroma', producer: 'Hacienda La Esmeralda', origin: 'San Vicente de Chucurí', sector: 'Agro', price: '$2.80 - $3.50', unit: 'USD/kg', moq: '500 kg', traceability: true, growth: '+34%' },
  { id: '2', name: 'Joyería Artesanal en Oro', producer: 'Orfebres Santander', origin: 'Barichara', sector: 'Joyería', price: '$120 - $450', unit: 'USD/pieza', moq: '20 piezas', traceability: true, growth: '+28%' },
  { id: '3', name: 'Calzado de Cuero Premium', producer: 'Calzado El Pionero', origin: 'Bucaramanga', sector: 'Calzado', price: '$35 - $80', unit: 'USD/par', moq: '100 pares', traceability: true, growth: '+19%' },
  { id: '4', name: 'Limón Tahití Ecológico', producer: 'Citricultores del Sur', origin: 'Vélez', sector: 'Cítricos', price: '$0.40 - $0.70', unit: 'USD/kg', moq: '1,000 kg', traceability: false, growth: '+15%' },
  { id: '5', name: 'Panela Orgánica Pulverizada', producer: 'Trapiche Los Andes', origin: 'Suaita', sector: 'Agro', price: '$1.20 - $1.80', unit: 'USD/kg', moq: '200 kg', traceability: true, growth: '+22%' },
  { id: '6', name: 'Chocolatería Fina Artesanal', producer: 'Cacao del Oriente SAS', origin: 'Lebrija', sector: 'Agro', price: '$8.00 - $15.00', unit: 'USD/caja', moq: '50 cajas', traceability: true, growth: '+31%' },
]

const SECTOR_COLORS: Record<string, { badge: string; border: string; bg: string; dot: string }> = {
  Agro:        { badge: 'bg-green-100 text-green-800 border-green-200',    border: 'border-t-green-500',   bg: 'bg-green-50',   dot: 'bg-green-500' },
  Joyería:     { badge: 'bg-amber-100 text-amber-800 border-amber-200',    border: 'border-t-amber-500',   bg: 'bg-amber-50',   dot: 'bg-amber-500' },
  Calzado:     { badge: 'bg-blue-100 text-blue-800 border-blue-200',       border: 'border-t-blue-500',    bg: 'bg-blue-50',    dot: 'bg-blue-500' },
  Cítricos:    { badge: 'bg-orange-100 text-orange-800 border-orange-200', border: 'border-t-orange-500',  bg: 'bg-orange-50',  dot: 'bg-orange-500' },
  Manufactura: { badge: 'bg-purple-100 text-purple-800 border-purple-200', border: 'border-t-purple-500',  bg: 'bg-purple-50',  dot: 'bg-purple-500' },
}

const SECTOR_ICONS: Record<string, string> = {
  Agro: '🌱', Joyería: '💎', Calzado: '👟', Cítricos: '🍋', Manufactura: '🏭'
}

const TRENDING = [
  { name: 'Cacao Fino',         growth: '+34%', pct: 85, buyers: '142 compradores activos', color: 'text-green-600',  dot: 'bg-green-500' },
  { name: 'Joyería Artesanal',  growth: '+28%', pct: 68, buyers: '89 compradores activos',  color: 'text-amber-600', dot: 'bg-amber-500' },
  { name: 'Calzado Premium',    growth: '+19%', pct: 52, buyers: '67 compradores activos',  color: 'text-blue-600',  dot: 'bg-blue-500' },
  { name: 'Cítricos Orgánicos', growth: '+15%', pct: 40, buyers: '54 compradores activos',  color: 'text-orange-600',dot: 'bg-orange-500' },
]

const ACTIVITY = [
  { colorClass: 'bg-blue-50 border-blue-100',   dot: 'bg-blue-500',             text: 'Cotización #COT-2024-003 en negociación con Hacienda La Esmeralda',  time: 'Hace 2h' },
  { colorClass: 'bg-green-50 border-green-100', dot: 'bg-green-500',            text: 'Pedido #ORD-2024-001 confirmado — Panela Orgánica 200 kg embarcada', time: 'Hace 1d' },
  { colorClass: 'bg-amber-50 border-amber-100', dot: 'bg-amber-500',            text: 'Nuevo mensaje de Orfebres Santander sobre joyería artesanal en oro',  time: 'Hace 3d' },
  { colorClass: 'bg-muted border-border',        dot: 'bg-muted-foreground/50', text: 'Limón Tahití Ecológico agregado a tu lista de seguimiento',           time: 'Hace 5d' },
]

export default function BuyerDashboardPage() {
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const t = (es: string, en: string) => lang === 'ES' ? es : en

  return (
    <BuyerLayout activePage="dashboard" lang={lang} onLangChange={setLang}>
      <div className="space-y-8">

        {/* ── Hero ──────────────────────────────────────────────────────── */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-primary/90 to-primary/80 p-6 md:p-8 text-primary-foreground">
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute -top-16 -right-16 w-64 h-64 bg-white/5 rounded-full blur-2xl" />
            <div className="absolute -bottom-8 -left-8 w-48 h-48 bg-white/5 rounded-full blur-xl" />
          </div>

          <div className="relative z-10">
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-5 mb-7">
              <div>
                <div className="inline-flex items-center gap-1.5 text-xs text-primary-foreground/70 bg-white/10 px-3 py-1 rounded-full border border-white/10 mb-3">
                  <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                  {t('Hecho en Colombia — Exportado al mundo', 'Made in Colombia — Exported to the world')}
                </div>
                <h1 className="text-2xl md:text-3xl font-bold leading-tight">
                  {t('Hola, Maria Gonzalez', 'Hello, Maria Gonzalez')} 👋
                </h1>
                <p className="text-sm text-primary-foreground/70 mt-1">
                  {t('Comprador Internacional · Global Trade GmbH · Alemania', 'International Buyer · Global Trade GmbH · Germany')}
                </p>
              </div>
              <div className="flex gap-3 flex-wrap">
                <Link
                  href="/buyer/catalog"
                  className="inline-flex items-center gap-2 px-4 py-2.5 bg-white text-primary rounded-xl text-sm font-semibold hover:bg-white/90 transition-colors shadow-sm"
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
                  </svg>
                  {t('Explorar Catálogo', 'Explore Catalog')}
                </Link>
                <Link
                  href="/buyer/quotes"
                  className="inline-flex items-center gap-2 px-4 py-2.5 bg-white/10 text-white border border-white/20 rounded-xl text-sm font-semibold hover:bg-white/20 transition-colors"
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                  </svg>
                  {t('Nueva Solicitud', 'New Request')}
                </Link>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-3">
              {[
                {
                  label: t('Productos Vistos', 'Products Viewed'),
                  value: '12',
                  sub: t('+3 esta semana', '+3 this week'),
                  icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
                },
                {
                  label: t('Cotizaciones Activas', 'Active Quotes'),
                  value: '3',
                  sub: t('1 en negociación', '1 negotiating'),
                  icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/></svg>,
                },
                {
                  label: t('Pedidos en Tránsito', 'Orders in Transit'),
                  value: '1',
                  sub: t('ETA 28 Nov', 'ETA Nov 28'),
                  icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>,
                },
              ].map((stat, i) => (
                <div key={i} className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                  <div className="text-primary-foreground/60 mb-2">{stat.icon}</div>
                  <div className="text-3xl font-bold text-white leading-none mb-1">{stat.value}</div>
                  <div className="text-xs text-primary-foreground/70 leading-tight">{stat.label}</div>
                  <div className="text-[10px] text-primary-foreground/50 mt-1">{stat.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Main 2-col grid ──────────────────────────────────────────── */}
        <div className="grid md:grid-cols-3 gap-6">

          {/* Market Insights */}
          <section className="md:col-span-1 bg-card rounded-2xl border border-border p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-semibold text-foreground">{t('Tendencias del Mercado', 'Market Trends')}</h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {t('Compradores en Alemania buscan:', 'Buyers in Germany are searching:')}
                </p>
              </div>
              <span className="text-[10px] bg-primary/10 text-primary px-2 py-1 rounded-full border border-primary/20 font-semibold whitespace-nowrap">
                {t('Esta semana', 'This week')}
              </span>
            </div>

            <div className="space-y-4">
              {TRENDING.map((s, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full flex-none ${s.dot}`} />
                      <span className="text-sm font-medium text-foreground">{s.name}</span>
                    </div>
                    <span className={`text-sm font-bold ${s.color}`}>{s.growth}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: `${s.pct}%` }} />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">{s.buyers}</p>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-border">
              <p className="text-xs text-muted-foreground leading-relaxed">
                {t(
                  'Compradores en Alemania buscan Cacao Fino (+34% esta semana). Considera contactar a Hacienda La Esmeralda.',
                  'Buyers in Germany are seeking Fine Cacao (+34% this week). Consider contacting Hacienda La Esmeralda.'
                )}
              </p>
            </div>
          </section>

          {/* Recent Activity */}
          <section className="md:col-span-2 bg-card rounded-2xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-semibold text-foreground">{t('Actividad Reciente', 'Recent Activity')}</h2>
              <Link href="/buyer/quotes" className="text-xs text-primary hover:underline font-medium">
                {t('Ver todo', 'View all')}
              </Link>
            </div>
            <div className="space-y-2.5">
              {ACTIVITY.map((a, i) => (
                <div key={i} className={`flex items-start gap-3 p-3.5 rounded-xl border ${a.colorClass}`}>
                  <div className={`w-2 h-2 rounded-full flex-none mt-1.5 ${a.dot}`} />
                  <p className="text-sm text-foreground flex-1 leading-snug">{a.text}</p>
                  <span className="text-xs text-muted-foreground flex-none whitespace-nowrap">{a.time}</span>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* ── Recommended Products ─────────────────────────────────────── */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold text-foreground">
                {t('Recomendados para Ti', 'Recommended for You')}
              </h2>
              <p className="text-sm text-muted-foreground mt-0.5">
                {t('Basado en tu perfil de comprador en Alemania', 'Based on your buyer profile in Germany')}
              </p>
            </div>
            <Link href="/buyer/catalog" className="text-sm text-primary hover:underline font-medium">
              {t('Ver todo', 'See all')} →
            </Link>
          </div>

          <div className="flex gap-4 overflow-x-auto pb-3" style={{ scrollbarWidth: 'none' }}>
            {RECOMMENDED_PRODUCTS.map((p) => {
              const s = SECTOR_COLORS[p.sector]
              return (
                <div
                  key={p.id}
                  className={`flex-none w-64 bg-card rounded-2xl border-t-4 border border-border ${s.border} hover:shadow-xl hover:-translate-y-1 transition-all duration-200 overflow-hidden`}
                >
                  <div className={`h-28 ${s.bg} flex items-center justify-center relative`}>
                    <div className={`w-14 h-14 rounded-2xl ${s.badge} flex items-center justify-center text-2xl border shadow-sm`}>
                      {SECTOR_ICONS[p.sector]}
                    </div>
                    <div className="absolute top-2.5 right-2.5">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${s.badge}`}>{p.sector}</span>
                    </div>
                    <div className="absolute top-2.5 left-2.5">
                      <span className="text-[10px] bg-green-100 text-green-700 border border-green-200 px-1.5 py-0.5 rounded-full font-semibold">{p.growth}</span>
                    </div>
                  </div>
                  <div className="p-3.5">
                    <h3 className="text-sm font-semibold text-foreground leading-tight mb-0.5">{p.name}</h3>
                    <p className="text-xs text-muted-foreground mb-0.5">{p.producer}</p>
                    <div className="flex items-center gap-1 mb-2.5">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-muted-foreground flex-none"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                      <span className="text-xs text-muted-foreground">{p.origin}</span>
                    </div>
                    {p.traceability && (
                      <div className="flex items-center gap-1.5 mb-2.5 py-1.5 px-2 bg-green-50 rounded-lg border border-green-100">
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-green-600 flex-none"><polyline points="20 6 9 17 4 12"/></svg>
                        <span className="text-xs text-green-700 font-medium">{t('Trazabilidad verificada', 'Verified traceability')}</span>
                      </div>
                    )}
                    <div className="border-t border-border pt-2.5 mt-1">
                      <p className="text-sm font-bold text-foreground">{p.price} <span className="text-xs font-normal text-muted-foreground">{p.unit}</span></p>
                      <p className="text-xs text-muted-foreground mb-3">{t('Min:', 'Min:')} {p.moq}</p>
                      <div className="flex gap-1.5">
                        <Link href={`/buyer/product/${p.id}`} className="flex-1 text-center py-1.5 text-xs border border-primary text-primary rounded-lg hover:bg-primary/5 transition-colors font-medium">
                          {t('Detalles', 'Details')}
                        </Link>
                        <Link href="/buyer/quotes" className="flex-1 text-center py-1.5 text-xs bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium">
                          {t('Cotizar', 'Quote')}
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </section>

        {/* ── Quick Actions ─────────────────────────────────────────────── */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { href: '/buyer/catalog',  icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>, label: t('Nuevo Pedido', 'New Order'), desc: t('Explorar catálogo', 'Browse catalog') },
            { href: '/buyer/quotes',   icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/></svg>, label: t('Cotizaciones', 'My Quotes'), desc: t('3 activas', '3 active') },
            { href: '/buyer/orders',   icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>, label: t('Seguimiento', 'Tracking'), desc: t('1 en tránsito', '1 in transit') },
            { href: '/buyer/messages', icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>, label: t('Mensajes', 'Messages'), desc: t('3 sin leer', '3 unread') },
          ].map((item, i) => (
            <Link key={i} href={item.href} className="group bg-card rounded-2xl border border-border p-4 hover:border-primary/40 hover:shadow-md transition-all duration-200">
              <div className="text-muted-foreground group-hover:text-primary transition-colors mb-2">{item.icon}</div>
              <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">{item.label}</p>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </Link>
          ))}
        </section>

      </div>
    </BuyerLayout>
  )
}
