'use client'

import { useState } from 'react'
import { BuyerLayout } from '@/components/buyer/buyer-layout'

interface Conversation {
  id: string
  producer: string
  initials: string
  product: string
  lastMessage: string
  time: string
  unread: number
  online: boolean
  messages: { from: 'buyer' | 'producer'; text: string; time: string }[]
}

const CONVERSATIONS: Conversation[] = [
  {
    id: '1', producer: 'Hacienda La Esmeralda', initials: 'HL', product: 'Cacao Fino de Aroma',
    lastMessage: 'Podemos ajustar el precio a $2.90 USD/kg para el volumen solicitado.', time: 'Hace 2h', unread: 2, online: true,
    messages: [
      { from: 'buyer', text: 'Hola, me interesa el cacao fino de aroma. ¿Tienen disponibilidad para noviembre?', time: '10:30 AM' },
      { from: 'producer', text: 'Claro, tenemos disponibilidad para noviembre. ¿Cuántos kilogramos necesitan?', time: '10:45 AM' },
      { from: 'buyer', text: 'Estamos pensando en unos 500 kg para empezar. ¿Cuál es el precio FOB Barranquilla?', time: '11:00 AM' },
      { from: 'producer', text: '$3.00 USD/kg FOB Barranquilla. Incluye certificado orgánico y análisis sensorial.', time: '11:30 AM' },
      { from: 'buyer', text: '¿Es posible llegar a $2.80? Sería una relación a largo plazo.', time: '12:00 PM' },
      { from: 'producer', text: 'Podemos ajustar el precio a $2.90 USD/kg para el volumen solicitado. ¿Les parece bien?', time: '2:45 PM' },
    ],
  },
  {
    id: '2', producer: 'Orfebres Santander', initials: 'OS', product: 'Joyería Artesanal en Oro',
    lastMessage: 'Gracias por tu solicitud. Revisaremos y responderemos en 24h.', time: 'Hace 1d', unread: 0, online: false,
    messages: [
      { from: 'buyer', text: 'Buenos días, solicité cotización para 20 piezas de joyería.', time: 'Ayer 3:00 PM' },
      { from: 'producer', text: 'Gracias por tu solicitud. Revisaremos y responderemos en las próximas 24 horas con propuesta detallada.', time: 'Ayer 5:30 PM' },
    ],
  },
  {
    id: '3', producer: 'Trapiche Los Andes', initials: 'TL', product: 'Panela Orgánica Pulverizada',
    lastMessage: 'Su pedido está en camino. Número de tracking: MSC-CG-2024-11847', time: 'Hace 3d', unread: 1, online: true,
    messages: [
      { from: 'producer', text: 'Estimada Maria, su pedido ORD-2024-001 ha sido embarcado en Barranquilla.', time: '3d 10:00 AM' },
      { from: 'producer', text: 'Su pedido está en camino. Número de tracking: MSC-CG-2024-11847. Llegada estimada 28 Nov.', time: '3d 10:05 AM' },
    ],
  },
  {
    id: '4', producer: 'Dulces de Vélez', initials: 'DV', product: 'Bocadillo Veleño Artesanal',
    lastMessage: 'Confirmamos recepción del pago. Iniciamos producción mañana.', time: 'Hace 2 sem', unread: 0, online: false,
    messages: [
      { from: 'buyer', text: '¿Pueden hacer el bocadillo en presentación de 200g para retail europeo?', time: '2 sem 9:00 AM' },
      { from: 'producer', text: 'Sí, podemos empacar en cajas de 200g con etiquetas en inglés y alemán.', time: '2 sem 10:30 AM' },
      { from: 'producer', text: 'Confirmamos recepción del pago. Iniciamos producción mañana.', time: '2 sem 4:00 PM' },
    ],
  },
]

export default function MessagesPage() {
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const [activeConv, setActiveConv] = useState<Conversation>(CONVERSATIONS[0])
  const [newMessage, setNewMessage] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [showTranslationHint, setShowTranslationHint] = useState(true)

  const t = (es: string, en: string) => lang === 'ES' ? es : en

  const filteredConvs = CONVERSATIONS.filter(c =>
    c.producer.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.product.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <BuyerLayout activePage="messages" lang={lang} onLangChange={setLang}>
      {/* Page Header */}
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-foreground">{t('Mensajes', 'Messages')}</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          {t('Conversaciones con productores colombianos', 'Conversations with Colombian producers')}
        </p>
      </div>

      <div className="flex gap-0 bg-card rounded-2xl border border-border overflow-hidden" style={{ height: 'calc(100vh - 175px)', minHeight: 500 }}>

        {/* Conversation List */}
        <div className="flex-none w-full sm:w-72 border-r border-border flex flex-col">
          {/* Search */}
          <div className="p-3 border-b border-border">
            <div className="relative">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
              </svg>
              <input
                type="search"
                placeholder={t('Buscar conversaciones...', 'Search conversations...')}
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm bg-muted border border-border rounded-xl focus:outline-none focus:border-primary text-foreground placeholder:text-muted-foreground"
              />
            </div>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto">
            {filteredConvs.map(conv => (
              <button
                key={conv.id}
                onClick={() => setActiveConv(conv)}
                className={`w-full flex items-start gap-3 p-3 text-left border-b border-border hover:bg-muted/50 transition-colors ${
                  activeConv.id === conv.id ? 'bg-primary/5 border-l-2 border-l-primary' : ''
                }`}
              >
                <div className="relative flex-none">
                  <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold text-sm">
                    {conv.initials}
                  </div>
                  {conv.online && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-card" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <p className="text-sm font-semibold text-foreground truncate">{conv.producer}</p>
                    <span className="text-[10px] text-muted-foreground flex-none ml-2">{conv.time}</span>
                  </div>
                  <p className="text-xs text-primary/70 truncate mb-0.5">{conv.product}</p>
                  <p className="text-xs text-muted-foreground truncate">{conv.lastMessage}</p>
                </div>
                {conv.unread > 0 && (
                  <span className="bg-destructive text-destructive-foreground text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-none mt-1">
                    {conv.unread}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Window */}
        <div className="hidden sm:flex flex-1 flex-col min-w-0">
          {/* Chat Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-border flex-none">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-9 h-9 bg-primary/20 rounded-full flex items-center justify-center text-primary font-bold text-sm">
                  {activeConv.initials}
                </div>
                {activeConv.online && (
                  <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-card" />
                )}
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">{activeConv.producer}</p>
                <p className="text-xs text-muted-foreground">{activeConv.product}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {activeConv.online && (
                <span className="flex items-center gap-1 text-xs text-green-600">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                  {t('En línea', 'Online')}
                </span>
              )}
            </div>
          </div>

          {/* Translation hint */}
          {showTranslationHint && (
            <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 border-b border-blue-200">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600 flex-none">
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              <p className="text-xs text-blue-800 flex-1">
                {t('Los mensajes se traducen automáticamente ES ↔ EN', 'Messages are automatically translated ES ↔ EN')}
              </p>
              <button onClick={() => setShowTranslationHint(false)} className="text-blue-500 hover:text-blue-700 flex-none text-xs">
                {t('Entendido', 'Got it')}
              </button>
            </div>
          )}

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {activeConv.messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.from === 'buyer' ? 'justify-end' : 'justify-start'}`}>
                {msg.from === 'producer' && (
                  <div className="w-7 h-7 bg-primary/10 rounded-full flex items-center justify-center text-primary text-[10px] font-bold mr-2 flex-none self-end">
                    {activeConv.initials}
                  </div>
                )}
                <div className={`max-w-[72%] ${msg.from === 'buyer' ? 'items-end' : 'items-start'} flex flex-col gap-0.5`}>
                  <div className={`rounded-2xl px-4 py-2.5 ${
                    msg.from === 'buyer'
                      ? 'bg-primary text-primary-foreground rounded-br-sm'
                      : 'bg-muted text-foreground rounded-bl-sm'
                  }`}>
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                  </div>
                  <p className="text-[10px] text-muted-foreground px-1">{msg.time}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Product chip */}
          <div className="px-4 py-1.5 border-t border-border flex-none">
            <div className="inline-flex items-center gap-1.5 text-xs bg-primary/10 text-primary px-2.5 py-1 rounded-full border border-primary/20">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
              {activeConv.product}
            </div>
          </div>

          {/* Input */}
          <div className="p-3 border-t border-border flex gap-2 flex-none">
            <button className="p-2 text-muted-foreground hover:text-foreground transition-colors">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
            </button>
            <input
              type="text"
              value={newMessage}
              onChange={e => setNewMessage(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && setNewMessage('')}
              placeholder={t('Escribe un mensaje...', 'Write a message...')}
              className="flex-1 border border-border rounded-xl px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary placeholder:text-muted-foreground"
            />
            <button
              onClick={() => setNewMessage('')}
              className="w-9 h-9 bg-primary text-primary-foreground rounded-xl flex items-center justify-center hover:bg-primary/90 transition-colors flex-none"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            </button>
          </div>
        </div>
      </div>
    </BuyerLayout>
  )
}
