'use client'

import { useState } from 'react'
import Link from 'next/link'
import { BuyerLayout } from '@/components/buyer/buyer-layout'

const ALL_PRODUCTS = [
  { id: '1', name: 'Cacao Fino de Aroma', producer: 'Hacienda La Esmeralda', origin: 'San Vicente de Chucurí', sector: 'Agro', price: 2.8, priceMax: 3.5, unit: 'kg', moq: 500, certs: ['Orgánico', 'Fair Trade'], traceability: true, desc: 'Cacao fino variedad Criollo con fermentación artesanal de 5 días y secado solar.' },
  { id: '2', name: 'Joyería Artesanal en Oro', producer: 'Orfebres Santander', origin: 'Barichara', sector: 'Joyería', price: 120, priceMax: 450, unit: 'pieza', moq: 20, certs: ['Artesanal', 'Certificado'], traceability: true, desc: 'Joyería en oro 18k trabajada a mano por artesanos certificados de Barichara.' },
  { id: '3', name: 'Calzado de Cuero Premium', producer: 'Calzado El Pionero', origin: 'Bucaramanga', sector: 'Calzado', price: 35, priceMax: 80, unit: 'par', moq: 100, certs: ['Fair Trade', 'ISO 9001'], traceability: true, desc: 'Calzado de cuero genuino colombiano, producción ética y de alta durabilidad.' },
  { id: '4', name: 'Limón Tahití Ecológico', producer: 'Citricultores del Sur', origin: 'Vélez', sector: 'Cítricos', price: 0.4, priceMax: 0.7, unit: 'kg', moq: 1000, certs: ['ECO'], traceability: false, desc: 'Limón Tahití fresco de cultivo ecológico, sin pesticidas, calibre exportación.' },
  { id: '5', name: 'Panela Orgánica Pulverizada', producer: 'Trapiche Los Andes', origin: 'Suaita', sector: 'Agro', price: 1.2, priceMax: 1.8, unit: 'kg', moq: 200, certs: ['Orgánico', 'NOP'], traceability: true, desc: 'Panela 100% orgánica pulverizada lista para exportación, certificación USDA.' },
  { id: '6', name: 'Esmeralda Natural Certificada', producer: 'Gemas de Colombia', origin: 'Bucaramanga', sector: 'Joyería', price: 200, priceMax: 2000, unit: 'ct', moq: 5, certs: ['GIA', 'Certificado'], traceability: true, desc: 'Esmeraldas colombianas certificadas, extracción responsable y cadena de custodia.' },
  { id: '7', name: 'Bocadillo Veleño Artesanal', producer: 'Dulces de Vélez', origin: 'Vélez', sector: 'Agro', price: 3.5, priceMax: 5.2, unit: 'kg', moq: 100, certs: ['Indicación Geográfica'], traceability: true, desc: 'Bocadillo con Indicación Geográfica Protegida, elaborado con guayaba de Vélez.' },
  { id: '8', name: 'Zapatos Artesanales Bordados', producer: 'Manos Artistas Bumanguesas', origin: 'Bucaramanga', sector: 'Calzado', price: 55, priceMax: 120, unit: 'par', moq: 50, certs: ['Artesanal'], traceability: false, desc: 'Calzado con bordados artesanales únicos, diseño colombiano contemporáneo.' },
  { id: '9', name: 'Mandarina Clementina Premium', producer: 'Citricultivos San Gil', origin: 'San Gil', sector: 'Cítricos', price: 0.6, priceMax: 1.0, unit: 'kg', moq: 500, certs: ['GlobalGAP'], traceability: true, desc: 'Mandarinas clementinas calibre premium, dulces y sin semillas para mercado europeo.' },
  { id: '10', name: 'Chocolatería Fina Artesanal', producer: 'Cacao del Oriente SAS', origin: 'Lebrija', sector: 'Agro', price: 8.0, priceMax: 15.0, unit: 'caja', moq: 50, certs: ['Orgánico', 'Fair Trade', 'FDA'], traceability: true, desc: 'Tabletas de chocolate artesanal 70-90% cacao, fermentación y conchado propio.' },
  { id: '11', name: 'Bolsos en Cuero Fino', producer: 'Cueroarte Santandereano', origin: 'Bucaramanga', sector: 'Manufactura', price: 45, priceMax: 180, unit: 'unidad', moq: 30, certs: ['Artesanal'], traceability: false, desc: 'Bolsos en cuero genuino colombiano, diseño contemporáneo y acabados de lujo.' },
  { id: '12', name: 'Arándano Andino Deshidratado', producer: 'Frutales de Altura', origin: 'San Vicente de Chucurí', sector: 'Agro', price: 12.0, priceMax: 18.0, unit: 'kg', moq: 50, certs: ['Orgánico', 'JAS'], traceability: true, desc: 'Arándanos andinos deshidratados sin azúcar añadida, cosecha de alta montaña.' },
]

const SECTORS = ['Agro', 'Joyería', 'Calzado', 'Manufactura', 'Cítricos']
const ORIGINS = ['Bucaramanga', 'San Gil', 'Barichara', 'Vélez', 'Suaita', 'San Vicente de Chucurí', 'Lebrija', 'Girón', 'Piedecuesta']
const CERTS = ['Orgánico', 'Fair Trade', 'FDA', 'JAS', 'GlobalGAP', 'ISO 9001', 'GIA', 'NOP', 'Artesanal']

const SECTOR_STYLE: Record<string, { badge: string; border: string; bg: string; icon: string }> = {
  Agro:        { badge: 'bg-green-100 text-green-800 border-green-200',   border: 'border-t-green-500',   bg: 'bg-green-50',   icon: '🌱' },
  Joyería:     { badge: 'bg-amber-100 text-amber-800 border-amber-200',   border: 'border-t-amber-500',   bg: 'bg-amber-50',   icon: '💎' },
  Calzado:     { badge: 'bg-blue-100 text-blue-800 border-blue-200',      border: 'border-t-blue-500',    bg: 'bg-blue-50',    icon: '👟' },
  Cítricos:    { badge: 'bg-orange-100 text-orange-800 border-orange-200', border: 'border-t-orange-500', bg: 'bg-orange-50',  icon: '🍋' },
  Manufactura: { badge: 'bg-purple-100 text-purple-800 border-purple-200', border: 'border-t-purple-500', bg: 'bg-purple-50',  icon: '🏭' },
}

export default function CatalogPage() {
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const [selectedSectors, setSelectedSectors] = useState<string[]>([])
  const [selectedOrigin, setSelectedOrigin] = useState('')
  const [selectedCerts, setSelectedCerts] = useState<string[]>([])
  const [priceMax, setPriceMax] = useState(2000)
  const [moqMax, setMoqMax] = useState(2000)
  const [searchQuery, setSearchQuery] = useState('')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [traceabilityOnly, setTraceabilityOnly] = useState(false)

  const t = (es: string, en: string) => lang === 'ES' ? es : en

  const toggleSector = (s: string) =>
    setSelectedSectors(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s])
  const toggleCert = (c: string) =>
    setSelectedCerts(prev => prev.includes(c) ? prev.filter(x => x !== c) : [...prev, c])

  const filtered = ALL_PRODUCTS.filter(p => {
    if (selectedSectors.length > 0 && !selectedSectors.includes(p.sector)) return false
    if (selectedOrigin && p.origin !== selectedOrigin) return false
    if (selectedCerts.length > 0 && !selectedCerts.some(c => p.certs.includes(c))) return false
    if (p.price > priceMax) return false
    if (p.moq > moqMax) return false
    if (searchQuery && !p.name.toLowerCase().includes(searchQuery.toLowerCase()) && !p.producer.toLowerCase().includes(searchQuery.toLowerCase())) return false
    if (traceabilityOnly && !p.traceability) return false
    return true
  })

  const FilterPanel = () => (
    <div className="space-y-6">
      {/* Sectors */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">{t('Sector', 'Sector')}</h3>
        <div className="space-y-2">
          {SECTORS.map(s => (
            <label key={s} className="flex items-center gap-2.5 cursor-pointer group">
              <input
                type="checkbox"
                checked={selectedSectors.includes(s)}
                onChange={() => toggleSector(s)}
                className="w-4 h-4 rounded border-border text-primary accent-primary"
              />
              <span className={`text-sm transition-colors ${selectedSectors.includes(s) ? 'text-primary font-medium' : 'text-muted-foreground group-hover:text-foreground'}`}>{s}</span>
              <span className={`ml-auto text-[10px] px-1.5 py-0.5 rounded border ${SECTOR_STYLE[s]?.badge}`}>{SECTOR_STYLE[s]?.icon}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Origin */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">{t('Origen', 'Origin')}</h3>
        <select
          value={selectedOrigin}
          onChange={e => setSelectedOrigin(e.target.value)}
          className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary"
        >
          <option value="">{t('Todos los municipios', 'All cities')}</option>
          {ORIGINS.map(o => <option key={o}>{o}</option>)}
        </select>
      </div>

      {/* Certifications */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">{t('Certificaciones', 'Certifications')}</h3>
        <div className="flex flex-wrap gap-1.5">
          {CERTS.map(c => (
            <button
              key={c}
              onClick={() => toggleCert(c)}
              className={`text-xs px-2.5 py-1 rounded-full border transition-all duration-150 ${
                selectedCerts.includes(c)
                  ? 'bg-primary text-primary-foreground border-primary scale-105'
                  : 'bg-background text-muted-foreground border-border hover:border-primary/50'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-foreground">{t('Precio máx.', 'Max price')}</h3>
          <span className="text-sm text-primary font-medium">${priceMax} USD</span>
        </div>
        <input
          type="range" min="1" max="2000" step="1"
          value={priceMax} onChange={e => setPriceMax(Number(e.target.value))}
          className="w-full accent-primary"
        />
      </div>

      {/* MOQ */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-foreground">{t('MOQ máx.', 'Max MOQ')}</h3>
          <span className="text-sm text-primary font-medium">{moqMax.toLocaleString()}</span>
        </div>
        <input
          type="range" min="1" max="2000" step="10"
          value={moqMax} onChange={e => setMoqMax(Number(e.target.value))}
          className="w-full accent-primary"
        />
      </div>

      {/* Traceability only */}
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">{t('Verificación', 'Verification')}</h3>
        <label className="flex items-center gap-2.5 cursor-pointer group">
          <button
            type="button"
            onClick={() => setTraceabilityOnly(v => !v)}
            className={`relative w-10 h-5 rounded-full transition-colors flex-none ${traceabilityOnly ? 'bg-primary' : 'bg-border'}`}
          >
            <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${traceabilityOnly ? 'translate-x-5' : 'translate-x-0.5'}`} />
          </button>
          <span className={`text-sm ${traceabilityOnly ? 'text-primary font-medium' : 'text-muted-foreground group-hover:text-foreground'}`}>
            {t('Solo trazabilidad verificada', 'Verified traceability only')}
          </span>
        </label>
      </div>

      {/* Reset */}
      <button
        onClick={() => { setSelectedSectors([]); setSelectedOrigin(''); setSelectedCerts([]); setPriceMax(2000); setMoqMax(2000); setTraceabilityOnly(false); }}
        className="w-full py-2 text-sm text-muted-foreground border border-border rounded-xl hover:bg-muted hover:text-foreground transition-colors"
      >
        {t('Limpiar filtros', 'Clear filters')}
      </button>
    </div>
  )

  return (
    <BuyerLayout activePage="catalog" lang={lang} onLangChange={setLang}>
      {/* Page Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">{t('Catálogo de Productos', 'Product Catalog')}</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {t('Descubre productos colombianos con trazabilidad verificada', 'Discover Colombian products with verified traceability')}
        </p>
      </div>

      <div className="flex gap-6">
        {/* Desktop Filter Sidebar */}
        <aside className="hidden lg:block w-56 flex-none">
          <div className="bg-card rounded-2xl border border-border p-5 sticky top-6">
            <h2 className="text-base font-semibold text-foreground mb-5">{t('Filtros', 'Filters')}</h2>
            <FilterPanel />
          </div>
        </aside>

        {/* Main */}
        <div className="flex-1 min-w-0">
          {/* Top bar */}
          <div className="flex items-center gap-3 mb-5">
            <div className="relative flex-1">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
              </svg>
              <input
                type="search"
                placeholder={t('Buscar productos o productores...', 'Search products or producers...')}
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 text-sm bg-card border border-border rounded-xl focus:outline-none focus:border-primary text-foreground placeholder:text-muted-foreground"
              />
            </div>
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden flex items-center gap-2 px-4 py-2.5 bg-card border border-border rounded-xl text-sm text-foreground hover:bg-muted transition-colors flex-none"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="14" y2="12"/><line x1="4" y1="18" x2="10" y2="18"/></svg>
              {t('Filtros', 'Filters')}
              {(selectedSectors.length + selectedCerts.length + (selectedOrigin ? 1 : 0)) > 0 && (
                <span className="bg-primary text-primary-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                  {selectedSectors.length + selectedCerts.length + (selectedOrigin ? 1 : 0)}
                </span>
              )}
            </button>
          </div>

          {/* Result count */}
          <p className="text-sm text-muted-foreground mb-4">
            {filtered.length} {t('productos encontrados', 'products found')}
          </p>

          {/* Grid */}
          {filtered.length === 0 ? (
            <div className="text-center py-16 bg-card rounded-2xl border border-border">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-muted-foreground mb-3"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
              <p className="text-muted-foreground">{t('No se encontraron productos con estos filtros', 'No products found with these filters')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map(p => {
                const s = SECTOR_STYLE[p.sector]
                return (
                  <div key={p.id} className={`bg-card rounded-xl border-t-4 border border-border ${s.border} hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5 overflow-hidden flex flex-col`}>
                    <div className={`h-32 ${s.bg} flex items-center justify-center`}>
                      <div className={`w-16 h-16 rounded-2xl ${s.badge} flex items-center justify-center text-3xl border`}>{s.icon}</div>
                    </div>
                    <div className="p-4 flex flex-col flex-1">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="text-sm font-semibold text-foreground leading-tight">{p.name}</h3>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded border flex-none ${s.badge}`}>{p.sector}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-0.5">{p.producer}</p>
                      <div className="flex items-center gap-1 mb-2">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-muted-foreground flex-none"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span className="text-xs text-muted-foreground">{p.origin}</span>
                      </div>
                      <p className="text-xs text-muted-foreground leading-snug mb-3 flex-1">{p.desc}</p>

                      {p.traceability && (
                        <div className="flex items-center gap-1 mb-2">
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="text-green-600"><polyline points="20 6 9 17 4 12"/></svg>
                          <span className="text-xs text-green-700 font-medium">{t('Trazabilidad verificada', 'Verified traceability')}</span>
                        </div>
                      )}

                      {/* Certs */}
                      <div className="flex flex-wrap gap-1 mb-3">
                        {p.certs.slice(0, 3).map(c => (
                          <span key={c} className="text-[10px] bg-muted text-muted-foreground px-1.5 py-0.5 rounded border border-border">{c}</span>
                        ))}
                      </div>

                      <div className="border-t border-border pt-3 mt-auto">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <p className="text-xs font-bold text-foreground">${p.price.toFixed(2)} - ${p.priceMax.toFixed(2)} USD/{p.unit}</p>
                            <p className="text-xs text-muted-foreground">{t('Min:', 'Min:')} {p.moq.toLocaleString()} {p.unit}s</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Link href={`/buyer/product/${p.id}`} className="flex-1 text-center py-2 text-xs border border-primary text-primary rounded-lg hover:bg-primary/5 transition-colors font-medium">
                            {t('Ver Detalles', 'View Details')}
                          </Link>
                          <Link href="/buyer/quotes" className="flex-1 text-center py-2 text-xs bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium">
                            {t('Solicitar Cotización', 'Request Quote')}
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="relative ml-auto w-72 bg-card h-full overflow-y-auto p-5">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold text-foreground">{t('Filtros', 'Filters')}</h2>
              <button onClick={() => setSidebarOpen(false)} className="text-muted-foreground hover:text-foreground">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <FilterPanel />
          </div>
        </div>
      )}
    </BuyerLayout>
  )
}
