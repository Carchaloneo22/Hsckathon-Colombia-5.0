'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

const COUNTRIES = [
  'United States', 'Canada', 'Mexico', 'Germany', 'France', 'Spain', 'Italy', 
  'United Kingdom', 'Netherlands', 'Belgium', 'Japan', 'South Korea', 'China',
  'Australia', 'Brazil', 'Argentina', 'Chile', 'Peru', 'Ecuador'
]

export default function BuyerAuthPage() {
  const router = useRouter()
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')

  // Form fields
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [companyName, setCompanyName] = useState('')
  const [country, setCountry] = useState('United States')

  const t = (es: string, en: string) => lang === 'ES' ? es : en

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    // Simulate authentication
    await new Promise(resolve => setTimeout(resolve, 1500))

    if (!email || !password) {
      setError(t('Por favor completa todos los campos', 'Please fill in all fields'))
      setLoading(false)
      return
    }

    if (mode === 'register' && !companyName) {
      setError(t('Por favor ingresa el nombre de tu empresa', 'Please enter your company name'))
      setLoading(false)
      return
    }

    // Redirect to buyer dashboard
    router.push('/buyer/dashboard')
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left Side - Brand Illustration */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-primary via-primary/90 to-primary/80 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-20 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-white/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-white/5 rounded-full blur-3xl" />
        </div>

        {/* Grid pattern overlay */}
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />

        <div className="relative z-10 flex flex-col justify-center px-12 xl:px-20 w-full">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-12">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center border border-white/20">
              <svg width="24" height="24" viewBox="0 0 18 18" fill="none">
                <circle cx="9" cy="9" r="7" stroke="white" strokeWidth="1.5"/>
                <circle cx="9" cy="9" r="2" fill="white"/>
                <line x1="9" y1="2" x2="9" y2="5.5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="9" y1="12.5" x2="9" y2="16" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="2" y1="9" x2="5.5" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="12.5" y1="9" x2="16" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <span className="font-bold text-white text-xl block leading-none">Exporta Santander</span>
              <span className="text-white/70 text-sm">{t('Conectando productores con el mundo', 'Connecting producers with the world')}</span>
            </div>
          </div>

          {/* Main headline */}
          <h1 className="text-4xl xl:text-5xl font-bold text-white leading-tight mb-6 text-balance">
            {t('Descubre productos colombianos con trazabilidad verificada', 'Discover Colombian products with verified traceability')}
          </h1>

          <p className="text-lg text-white/80 mb-10 leading-relaxed max-w-lg">
            {t(
              'Accede al catalogo mas completo de productos de exportacion de Santander. Cacao, cafe, joyeria artesanal, calzado y mas.',
              'Access the most complete catalog of export products from Santander. Cocoa, coffee, artisan jewelry, footwear and more.'
            )}
          </p>

          {/* Product categories preview */}
          <div className="grid grid-cols-2 gap-3 max-w-md">
            {[
              { icon: '🌱', label: t('Agroindustria', 'Agribusiness'), color: 'bg-green-500/20' },
              { icon: '💎', label: t('Joyeria Artesanal', 'Artisan Jewelry'), color: 'bg-amber-500/20' },
              { icon: '👟', label: t('Calzado', 'Footwear'), color: 'bg-blue-500/20' },
              { icon: '🍋', label: t('Citricos', 'Citrus'), color: 'bg-orange-500/20' },
            ].map((cat, i) => (
              <div key={i} className={`${cat.color} backdrop-blur-sm rounded-xl px-4 py-3 border border-white/10 flex items-center gap-3`}>
                <span className="text-2xl">{cat.icon}</span>
                <span className="text-white font-medium text-sm">{cat.label}</span>
              </div>
            ))}
          </div>

          {/* Trust badge */}
          <div className="mt-12 flex items-center gap-3">
            <div className="flex -space-x-2">
              {['CA', 'MG', 'JR', 'LP'].map((initials, i) => (
                <div key={i} className="w-9 h-9 rounded-full bg-white/20 border-2 border-white/30 flex items-center justify-center text-white text-xs font-semibold">
                  {initials}
                </div>
              ))}
            </div>
            <div className="text-white/80 text-sm">
              <span className="font-semibold text-white">+500</span> {t('compradores activos', 'active buyers')}
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="w-full lg:w-1/2 flex flex-col">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          {/* Mobile logo */}
          <Link href="/bienvenida" className="flex items-center gap-2 lg:hidden">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 18 18" fill="none">
                <circle cx="9" cy="9" r="7" stroke="white" strokeWidth="1.5"/>
                <circle cx="9" cy="9" r="2" fill="white"/>
                <line x1="9" y1="2" x2="9" y2="5.5" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="9" y1="12.5" x2="9" y2="16" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="2" y1="9" x2="5.5" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                <line x1="12.5" y1="9" x2="16" y2="9" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <span className="font-semibold text-foreground">Exporta Santander</span>
          </Link>
          <div className="hidden lg:block" />

          {/* Language toggle */}
          <div className="flex items-center gap-1 bg-muted rounded-full p-1">
            <button
              onClick={() => setLang('ES')}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                lang === 'ES' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              ES
            </button>
            <button
              onClick={() => setLang('EN')}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                lang === 'EN' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              EN
            </button>
          </div>
        </div>

        {/* Form container */}
        <div className="flex-1 flex items-center justify-center px-6 py-12">
          <div className="w-full max-w-md">
            {/* Role badge */}
            <div className="flex justify-center mb-6">
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm px-4 py-2 rounded-full border border-primary/20">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"/>
                  <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/>
                  <path d="M2 12h20"/>
                </svg>
                {t('Comprador Internacional', 'International Buyer')}
              </div>
            </div>

            {/* Mode toggle */}
            <div className="flex bg-muted rounded-xl p-1 mb-8">
              <button
                onClick={() => setMode('login')}
                className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  mode === 'login' 
                    ? 'bg-card text-foreground shadow-sm' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('Iniciar sesion', 'Sign in')}
              </button>
              <button
                onClick={() => setMode('register')}
                className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  mode === 'register' 
                    ? 'bg-card text-foreground shadow-sm' 
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('Crear cuenta', 'Create account')}
              </button>
            </div>

            {/* Heading */}
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">
                {mode === 'login' 
                  ? t('Bienvenido de nuevo', 'Welcome back')
                  : t('Crea tu cuenta', 'Create your account')
                }
              </h2>
              <p className="text-muted-foreground text-sm">
                {mode === 'login'
                  ? t('Ingresa tus credenciales para acceder', 'Enter your credentials to access')
                  : t('Completa tus datos para comenzar', 'Complete your details to get started')
                }
              </p>
            </div>

            {/* Error message */}
            {error && (
              <div className="mb-6 p-3 bg-destructive/10 border border-destructive/20 text-destructive text-sm rounded-xl flex items-center gap-2">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flex-none">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="8" x2="12" y2="12"/>
                  <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                {error}
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  {t('Correo electronico', 'Email address')} <span className="text-destructive">*</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="tu@empresa.com"
                  disabled={loading}
                  required
                  className="w-full px-4 py-3 border border-border rounded-xl bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all disabled:opacity-50"
                />
              </div>

              {/* Password */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-sm font-medium text-foreground">
                    {t('Contrasena', 'Password')} <span className="text-destructive">*</span>
                  </label>
                  {mode === 'login' && (
                    <Link href="/recuperar-password" className="text-xs text-primary hover:underline">
                      {t('Olvidaste tu contrasena?', 'Forgot password?')}
                    </Link>
                  )}
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    disabled={loading}
                    required
                    className="w-full px-4 py-3 pr-12 border border-border rounded-xl bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? (
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
                        <line x1="1" y1="1" x2="23" y2="23"/>
                      </svg>
                    ) : (
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                        <circle cx="12" cy="12" r="3"/>
                      </svg>
                    )}
                  </button>
                </div>
              </div>

              {/* Register-only fields */}
              {mode === 'register' && (
                <>
                  {/* Company name */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">
                      {t('Nombre de la empresa', 'Company name')} <span className="text-destructive">*</span>
                    </label>
                    <input
                      type="text"
                      value={companyName}
                      onChange={e => setCompanyName(e.target.value)}
                      placeholder={t('Tu empresa S.A.', 'Your Company Inc.')}
                      disabled={loading}
                      required
                      className="w-full px-4 py-3 border border-border rounded-xl bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all disabled:opacity-50"
                    />
                  </div>

                  {/* Country */}
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">
                      {t('Pais', 'Country')}
                    </label>
                    <select
                      value={country}
                      onChange={e => setCountry(e.target.value)}
                      disabled={loading}
                      className="w-full px-4 py-3 border border-border rounded-xl bg-background text-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all disabled:opacity-50"
                    >
                      {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                    <p className="text-xs text-muted-foreground mt-1.5">
                      {t('Detectado automaticamente. Puedes cambiarlo si es incorrecto.', 'Auto-detected. You can change it if incorrect.')}
                    </p>
                  </div>
                </>
              )}

              {/* Submit button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-primary text-primary-foreground rounded-xl font-semibold text-sm hover:bg-primary/90 transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30"
              >
                {loading ? (
                  <>
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                    </svg>
                    {mode === 'login' ? t('Iniciando sesion...', 'Signing in...') : t('Creando cuenta...', 'Creating account...')}
                  </>
                ) : (
                  mode === 'login' ? t('Iniciar sesion', 'Sign in') : t('Crear cuenta', 'Create account')
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-3 text-muted-foreground">{t('O continua con', 'Or continue with')}</span>
              </div>
            </div>

            {/* Social login */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                disabled={loading}
                className="flex items-center justify-center gap-2 px-4 py-3 border border-border rounded-xl text-sm font-medium text-foreground hover:bg-muted transition-colors disabled:opacity-50"
              >
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                Google
              </button>
              <button
                type="button"
                disabled={loading}
                className="flex items-center justify-center gap-2 px-4 py-3 border border-border rounded-xl text-sm font-medium text-foreground hover:bg-muted transition-colors disabled:opacity-50"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
                LinkedIn
              </button>
            </div>

            {/* Switch role link */}
            <div className="mt-8 text-center">
              <p className="text-sm text-muted-foreground">
                {t('Eres productor?', 'Are you a producer?')}{' '}
                <Link href="/login" className="text-primary font-medium hover:underline">
                  {t('Cambiar rol', 'Switch role')}
                </Link>
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border">
          <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
            <Link href="/terminos" className="hover:text-foreground transition-colors">{t('Terminos', 'Terms')}</Link>
            <span>·</span>
            <Link href="/privacidad" className="hover:text-foreground transition-colors">{t('Privacidad', 'Privacy')}</Link>
            <span>·</span>
            <Link href="/ayuda" className="hover:text-foreground transition-colors">{t('Ayuda', 'Help')}</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
