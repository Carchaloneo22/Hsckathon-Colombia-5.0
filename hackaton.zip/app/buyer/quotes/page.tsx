'use client'

import { useState } from 'react'
import Link from 'next/link'
import { BuyerLayout } from '@/components/buyer/buyer-layout'

type QuoteStatus = 'Pendiente' | 'En negociación' | 'Aceptada' | 'Rechazada'

interface Quote {
  id: string
  product: string
  producer: string
  origin: string
  qty: string
  unit: string
  status: QuoteStatus
  date: string
  lastMessage: string
  messages: { from: 'buyer' | 'producer'; text: string; time: string }[]
  proposedPrice: string
}

const QUOTES: Quote[] = [
  {
    id: 'COT-2024-003',
    product: 'Cacao Fino de Aroma',
    producer: 'Hacienda La Esmeralda',
    origin: 'San Vicente de Chucurí',
    qty: '500', unit: 'kg',
    status: 'En negociación',
    date: 'Hace 2h',
    lastMessage: 'Podemos ajustar el precio a $2.90 USD/kg para el volumen solicitado.',
    proposedPrice: '$2.90 USD/kg',
    messages: [
      { from: 'buyer', text: 'Hola, estoy interesado en 500 kg de cacao fino. ¿Pueden ofrecer certificado orgánico USDA?', time: '10:30 AM' },
      { from: 'producer', text: 'Buenos días. Sí, contamos con certificación USDA Orgánico vigente. El precio base es $3.00 USD/kg FOB Barranquilla.', time: '11:15 AM' },
      { from: 'buyer', text: 'Perfecto. ¿Es posible bajar a $2.80 USD/kg para 500 kg con entrega en Rotterdam?', time: '12:00 PM' },
      { from: 'producer', text: 'Podemos ajustar el precio a $2.90 USD/kg para el volumen solicitado. Incluimos certificado COA y trazabilidad completa.', time: '2:45 PM' },
    ],
  },
  {
    id: 'COT-2024-002',
    product: 'Joyería Artesanal en Oro',
    producer: 'Orfebres Santander',
    origin: 'Barichara',
    qty: '20', unit: 'piezas',
    status: 'Pendiente',
    date: 'Hace 1d',
    lastMessage: 'Gracias por tu solicitud. Revisaremos y responderemos en 24h.',
    proposedPrice: 'Por confirmar',
    messages: [
      { from: 'buyer', text: 'Me interesan 20 piezas de joyería en oro 18k, diseño floral. ¿Tiempo de entrega?', time: 'Ayer 3:00 PM' },
      { from: 'producer', text: 'Gracias por tu solicitud. Revisaremos y responderemos en las próximas 24 horas con propuesta detallada.', time: 'Ayer 5:30 PM' },
    ],
  },
  {
    id: 'COT-2024-001',
    product: 'Panela Orgánica Pulverizada',
    producer: 'Trapiche Los Andes',
    origin: 'Suaita',
    qty: '200', unit: 'kg',
    status: 'Aceptada',
    date: 'Hace 5d',
    lastMessage: 'Propuesta aceptada. Procederemos con el pedido.',
    proposedPrice: '$1.45 USD/kg',
    messages: [
      { from: 'buyer', text: 'Necesitamos 200 kg de panela orgánica para distribución en Alemania. ¿Tienen certificación NOP?', time: '5d 10:00 AM' },
      { from: 'producer', text: 'Sí, contamos con NOP y USDA Orgánico. Precio: $1.50 USD/kg FOB Buenaventura.', time: '5d 2:00 PM' },
      { from: 'buyer', text: '¿Podemos cerrar a $1.45 USD/kg incluyendo análisis de laboratorio?', time: '4d 9:00 AM' },
      { from: 'producer', text: 'Aceptamos. $1.45 USD/kg con análisis de residuos incluido. ¿Avanzamos con el pedido?', time: '4d 11:30 AM' },
      { from: 'buyer', text: 'Propuesta aceptada. Procederemos con el pedido.', time: '4d 12:00 PM' },
    ],
  },
  {
    id: 'COT-2023-047',
    product: 'Limón Tahití Ecológico',
    producer: 'Citricultores del Sur',
    origin: 'Vélez',
    qty: '1000', unit: 'kg',
    status: 'Rechazada',
    date: 'Hace 2 sem',
    lastMessage: 'El productor no pudo cumplir con las certificaciones requeridas.',
    proposedPrice: 'N/A',
    messages: [
      { from: 'buyer', text: 'Solicito cotización para 1.000 kg de limón Tahití con certificación GlobalGAP.', time: '2 sem 10:00 AM' },
      { from: 'producer', text: 'Hola. Actualmente no contamos con GlobalGAP, solo con certificación local. ¿Podría ser útil?', time: '2 sem 3:00 PM' },
      { from: 'buyer', text: 'Lamentablemente necesitamos GlobalGAP para el mercado europeo. No podemos continuar sin esa certificación.', time: '2 sem 5:00 PM' },
    ],
  },
]

const STATUS_STYLE: Record<QuoteStatus, string> = {
  Pendiente:        'bg-yellow-100 text-yellow-800 border-yellow-200',
  'En negociación': 'bg-blue-100 text-blue-800 border-blue-200',
  Aceptada:         'bg-green-100 text-green-800 border-green-200',
  Rechazada:        'bg-red-100 text-red-800 border-red-200',
}

export default function QuotesPage() {
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null)
  const [filterStatus, setFilterStatus] = useState<QuoteStatus | 'Todas'>('Todas')
  const [newMessage, setNewMessage] = useState('')
  const [showConfetti, setShowConfetti] = useState(false)

  const t = (es: string, en: string) => lang === 'ES' ? es : en

  const statuses: (QuoteStatus | 'Todas')[] = ['Todas', 'Pendiente', 'En negociación', 'Aceptada', 'Rechazada']
  const filtered = filterStatus === 'Todas' ? QUOTES : QUOTES.filter(q => q.status === filterStatus)

  const handleAccept = () => {
    setShowConfetti(true)
    setTimeout(() => setShowConfetti(false), 3000)
    setSelectedQuote(null)
  }

  return (
    <BuyerLayout activePage="quotes" lang={lang} onLangChange={setLang}>

      {/* Confetti effect */}
      {showConfetti && (
        <div className="fixed inset-0 z-50 pointer-events-none overflow-hidden">
          {Array.from({ length: 30 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-2.5 h-2.5 rounded-sm animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 60}%`,
                backgroundColor: ['#166534', '#22c55e', '#fbbf24', '#3b82f6', '#f97316'][i % 5],
                animationDelay: `${Math.random() * 0.5}s`,
                animationDuration: `${0.6 + Math.random() * 0.5}s`,
                transform: `rotate(${Math.random() * 360}deg)`,
              }}
            />
          ))}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="bg-card border border-border rounded-2xl p-6 shadow-xl text-center">
              <div className="text-4xl mb-2">✓</div>
              <p className="text-lg font-bold text-foreground">{t('¡Propuesta Aceptada!', 'Proposal Accepted!')}</p>
              <p className="text-sm text-muted-foreground">{t('El pedido está siendo procesado', 'The order is being processed')}</p>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">{t('Mis Cotizaciones', 'My Quotes')}</h1>
            <p className="text-sm text-muted-foreground">{t('Gestiona tus solicitudes de cotización con productores colombianos', 'Manage your quote requests with Colombian producers')}</p>
          </div>
          <Link href="/buyer/catalog" className="inline-flex items-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors shadow-sm">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            {t('Nueva Cotización', 'New Quote')}
          </Link>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: t('Total', 'Total'),             value: QUOTES.length,                                      style: 'border-border' },
            { label: t('Pendientes', 'Pending'),       value: QUOTES.filter(q => q.status === 'Pendiente').length,        style: 'border-yellow-300 bg-yellow-50' },
            { label: t('En negociación', 'Negotiating'),value: QUOTES.filter(q => q.status === 'En negociación').length, style: 'border-blue-300 bg-blue-50' },
            { label: t('Aceptadas', 'Accepted'),       value: QUOTES.filter(q => q.status === 'Aceptada').length,         style: 'border-green-300 bg-green-50' },
          ].map((s, i) => (
            <div key={i} className={`rounded-xl border p-3 text-center ${s.style}`}>
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Status filter */}
        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: 'none' }}>
          {statuses.map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`flex-none px-4 py-1.5 rounded-full text-sm font-medium border transition-all ${
                filterStatus === s
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-card text-muted-foreground border-border hover:border-primary/40 hover:text-foreground'
              }`}
            >
              {t(s, s)} {s !== 'Todas' && `(${QUOTES.filter(q => q.status === s).length})`}
            </button>
          ))}
        </div>

        {/* Quotes List */}
        <div className="space-y-3">
          {filtered.map(quote => (
            <div
              key={quote.id}
              onClick={() => setSelectedQuote(quote)}
              className="bg-card rounded-xl border border-border p-4 hover:border-primary/30 hover:shadow-md transition-all duration-150 cursor-pointer group"
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <h3 className="text-sm font-semibold text-foreground">{quote.product}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${STATUS_STYLE[quote.status]}`}>
                      {t(quote.status, quote.status)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{quote.producer} · {quote.origin}</p>
                </div>
                <div className="text-right flex-none">
                  <p className="text-xs font-bold text-foreground">{quote.proposedPrice}</p>
                  <p className="text-xs text-muted-foreground">{quote.id}</p>
                </div>
              </div>

              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-muted-foreground flex-none"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                  <p className="text-xs text-muted-foreground truncate">{quote.lastMessage}</p>
                </div>
                <span className="text-xs text-muted-foreground flex-none">{quote.date}</span>
              </div>

              <div className="flex items-center gap-3 mt-3 pt-3 border-t border-border">
                <span className="text-xs text-muted-foreground">{quote.qty} {quote.unit}s</span>
                <span className="text-xs text-muted-foreground">·</span>
                <span className="text-xs text-muted-foreground">{quote.messages.length} {t('mensajes', 'messages')}</span>
                <span className="ml-auto text-xs text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                  {t('Ver conversación', 'View conversation')} →
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quote Detail Drawer */}
      {selectedQuote && (
        <div className="fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSelectedQuote(null)} />
          <div className="relative ml-auto w-full max-w-md bg-card flex flex-col h-full">
            {/* Header */}
            <div className="flex items-start justify-between p-4 border-b border-border flex-none">
              <div>
                <h3 className="text-base font-semibold text-foreground">{selectedQuote.product}</h3>
                <p className="text-xs text-muted-foreground">{selectedQuote.producer} · {selectedQuote.id}</p>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${STATUS_STYLE[selectedQuote.status]}`}>
                  {selectedQuote.status}
                </span>
                <button onClick={() => setSelectedQuote(null)} className="text-muted-foreground hover:text-foreground ml-1">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {selectedQuote.messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.from === 'buyer' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 ${
                    msg.from === 'buyer'
                      ? 'bg-primary text-primary-foreground rounded-br-sm'
                      : 'bg-muted text-foreground rounded-bl-sm'
                  }`}>
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                    <p className={`text-[10px] mt-1 ${msg.from === 'buyer' ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>{msg.time}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Actions */}
            {selectedQuote.status === 'En negociación' && (
              <div className="p-4 border-t border-border flex gap-2 flex-none">
                <button onClick={handleAccept} className="flex-1 py-2 bg-green-600 text-white rounded-xl text-sm font-medium hover:bg-green-700 transition-colors">
                  {t('Aceptar propuesta', 'Accept proposal')}
                </button>
                <button className="flex-1 py-2 border border-border rounded-xl text-sm text-foreground hover:bg-muted transition-colors">
                  {t('Solicitar ajuste', 'Request adjustment')}
                </button>
              </div>
            )}

            {/* Reply input */}
            {(selectedQuote.status === 'Pendiente' || selectedQuote.status === 'En negociación') && (
              <div className="p-4 border-t border-border flex gap-2 flex-none">
                <input
                  type="text"
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  placeholder={t('Escribe un mensaje...', 'Write a message...')}
                  className="flex-1 border border-border rounded-xl px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary placeholder:text-muted-foreground"
                />
                <button
                  onClick={() => setNewMessage('')}
                  className="w-10 h-10 bg-primary text-primary-foreground rounded-xl flex items-center justify-center hover:bg-primary/90 transition-colors flex-none"
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </BuyerLayout>
  )
}
