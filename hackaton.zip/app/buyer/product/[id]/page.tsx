'use client'

import { useState } from 'react'
import Link from 'next/link'
import { BuyerLayout } from '@/components/buyer/buyer-layout'

const PRODUCTS: Record<string, {
  name: string; producer: string; origin: string; sector: string;
  price: string; priceMin: number; priceMax: number; unit: string; moq: number;
  desc: string; capacity: string; leadTime: string; certs: string[];
  traceabilityStages: { icon: string; title: string; date: string; desc: string; verified: boolean }[];
  shipping: { port: string; time: string; incoterm: string }[];
}> = {
  '1': {
    name: 'Cacao Fino de Aroma',
    producer: 'Hacienda La Esmeralda',
    origin: 'San Vicente de Chucurí, Santander',
    sector: 'Agro',
    price: '$2.80 - $3.50 USD/kg',
    priceMin: 2.8, priceMax: 3.5, unit: 'kg', moq: 500,
    desc: 'Cacao fino de aroma variedad Criollo cultivado en alturas de 600-900 msnm en el corazón del Magdalena Medio santandereano. Fermentación artesanal de 5-6 días y secado solar. Perfil de sabor: frutas rojas, notas florales y baja acidez. Reconocido por la ICCO como "Cacao Fino de Aroma".',
    capacity: '2.5 toneladas/mes',
    leadTime: '15 - 21 días',
    certs: ['Certificado Orgánico USDA', 'Fair Trade FLO', 'Rainforest Alliance', 'UTZ Certified'],
    traceabilityStages: [
      { icon: '🌱', title: 'Siembra y Cultivo', date: 'Ene - Feb 2024', desc: 'Semillas Criollo certificadas plantadas a 3x3m, manejo agroecológico sin agroquímicos.', verified: true },
      { icon: '🍫', title: 'Cosecha Selectiva', date: '15 Ago 2024', desc: 'Mazorcas seleccionadas manualmente en punto de madurez óptimo. Lote: SAN-AG-001.', verified: true },
      { icon: '🔄', title: 'Fermentación', date: '15 - 21 Ago 2024', desc: 'Fermentación anaeróbica 2 días + aeróbica 4 días en cajones de madera. T° controlada 45-50°C.', verified: true },
      { icon: '☀️', title: 'Secado Solar', date: '22 Ago - 01 Sep 2024', desc: 'Secado natural al sol durante 10 días. Humedad final: 7.5%. Volteo manual 2x/día.', verified: true },
      { icon: '🔬', title: 'Control de Calidad', date: '02 Sep 2024', desc: 'Análisis físico (% granos defectuosos < 2%) y sensorial por catadores certificados ICONTEC.', verified: true },
      { icon: '📦', title: 'Empaque y Etiquetado', date: '05 Sep 2024', desc: 'Empaque en sacos de yute 60kg con trazabilidad QR. Almacenamiento a 18°C, HR 65%.', verified: true },
    ],
    shipping: [
      { port: 'Barranquilla (IMBAQ)', time: '25-30 días a Hamburgo', incoterm: 'FOB / CFR / CIF' },
      { port: 'Cartagena (COBUN)', time: '23-28 días a Rotterdam', incoterm: 'FOB / CFR / CIF' },
      { port: 'Buenaventura (COBUN)', time: '30-35 días a Los Angeles', incoterm: 'FOB / CIF' },
    ],
  },
  '2': {
    name: 'Joyería Artesanal en Oro',
    producer: 'Orfebres Santander',
    origin: 'Barichara, Santander',
    sector: 'Joyería',
    price: '$120 - $450 USD/pieza',
    priceMin: 120, priceMax: 450, unit: 'pieza', moq: 20,
    desc: 'Joyería en oro 18k trabajada completamente a mano por artesanos certificados de Barichara. Cada pieza es única con acabados mates, pulidos y combinaciones de filigrana. Diseños inspirados en la naturaleza colombiana y la tradición precolombina.',
    capacity: '150 piezas/mes',
    leadTime: '30 - 45 días',
    certs: ['Artesanías de Colombia', 'Certificado de Autenticidad', 'RUC Exportador'],
    traceabilityStages: [
      { icon: '✏️', title: 'Diseño y Boceto', date: '10 Jul 2024', desc: 'Boceto artesanal aprobado por el cliente. Número de diseño: BAR-JOY-2024-048.', verified: true },
      { icon: '🔥', title: 'Fundición', date: '15 Jul 2024', desc: 'Fusión de oro 18k certificado a 1.064°C. Aleación con plata 750 y cobre 250 milésimas.', verified: true },
      { icon: '🔨', title: 'Laminado y Corte', date: '16 Jul 2024', desc: 'Laminado a espesor 0.5mm y corte manual con cincel y buril tradicional.', verified: true },
      { icon: '💫', title: 'Filigrana y Acabados', date: '17 - 25 Jul 2024', desc: 'Trabajo de filigrana con hilos de oro de 0.2mm. Proceso manual de 8 horas por pieza.', verified: true },
      { icon: '🔍', title: 'Certificación', date: '26 Jul 2024', desc: 'Certificación de pureza (18k = 750/1000), peso y autenticidad por laboratorio acreditado.', verified: true },
      { icon: '📦', title: 'Empaque Premium', date: '28 Jul 2024', desc: 'Estuche de madera de nogal con certificado de autenticidad y código QR de trazabilidad.', verified: true },
    ],
    shipping: [
      { port: 'Bogotá (BOG - Carga aérea)', time: '2-3 días a Miami / 5-7 días a Europa', incoterm: 'DAP / DDP' },
      { port: 'Barranquilla (IMBAQ)', time: '15-20 días a Nueva York', incoterm: 'FOB / CIF' },
    ],
  },
}

const SECTOR_STYLE: Record<string, { badge: string; bg: string; icon: string }> = {
  Agro:        { badge: 'bg-green-100 text-green-800 border-green-200',   bg: 'bg-green-50',  icon: '🌱' },
  Joyería:     { badge: 'bg-amber-100 text-amber-800 border-amber-200',   bg: 'bg-amber-50',  icon: '💎' },
  Calzado:     { badge: 'bg-blue-100 text-blue-800 border-blue-200',      bg: 'bg-blue-50',   icon: '👟' },
  Cítricos:    { badge: 'bg-orange-100 text-orange-800 border-orange-200', bg: 'bg-orange-50', icon: '🍋' },
  Manufactura: { badge: 'bg-purple-100 text-purple-800 border-purple-200', bg: 'bg-purple-50', icon: '🏭' },
}

const COUNTRIES = ['Alemania', 'Estados Unidos', 'Francia', 'Países Bajos', 'Japón', 'Reino Unido', 'España', 'Canadá', 'Italia', 'Bélgica', 'Suiza', 'Australia']

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const [lang, setLang] = useState<'ES' | 'EN'>('ES')
  const [activeTab, setActiveTab] = useState<'descripcion' | 'trazabilidad' | 'certificaciones' | 'logistica'>('trazabilidad')
  const [qty, setQty] = useState(500)
  const [destCountry, setDestCountry] = useState('Alemania')
  const [message, setMessage] = useState('')
  const [showSuccess, setShowSuccess] = useState(false)
  const [certModal, setCertModal] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  const t = (es: string, en: string) => lang === 'ES' ? es : en

  const product = PRODUCTS[params.id] || PRODUCTS['1']
  const style = SECTOR_STYLE[product.sector] || SECTOR_STYLE['Agro']

  const handleSubmitQuote = () => {
    setShowSuccess(true)
    setTimeout(() => setShowSuccess(false), 4000)
    setMessage('')
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`https://exportasantander.co/verify/${params.id}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const TABS = [
    { id: 'descripcion' as const,     label: t('Descripción', 'Description') },
    { id: 'trazabilidad' as const,    label: t('Trazabilidad', 'Traceability') },
    { id: 'certificaciones' as const, label: t('Certificaciones', 'Certifications') },
    { id: 'logistica' as const,       label: t('Logística', 'Logistics') },
  ]

  return (
    <BuyerLayout activePage="catalog" lang={lang} onLangChange={setLang}>
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-5">
        <Link href="/buyer/catalog" className="hover:text-foreground transition-colors">{t('Catálogo', 'Catalog')}</Link>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
        <span className="text-foreground font-medium truncate">{product.name}</span>
      </nav>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-5">
          {/* Product Header */}
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            <div className={`h-48 ${style.bg} flex items-center justify-center relative`}>
              <div className={`w-24 h-24 rounded-3xl ${style.badge} flex items-center justify-center text-5xl border-2`}>
                {style.icon}
              </div>
              <div className="absolute top-4 left-4 flex gap-2">
                <span className={`text-xs px-2.5 py-1 rounded-full border font-medium ${style.badge}`}>{product.sector}</span>
                {product.traceabilityStages && (
                  <span className="text-xs px-2.5 py-1 rounded-full bg-green-100 text-green-800 border border-green-200 font-medium">
                    {t('Verificado', 'Verified')}
                  </span>
                )}
              </div>
            </div>
            <div className="p-5">
              <h1 className="text-2xl font-bold text-foreground mb-1">{product.name}</h1>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                  {product.producer}
                </span>
                <span className="flex items-center gap-1.5">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                  {product.origin}
                </span>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            <div className="flex border-b border-border overflow-x-auto">
              {TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-none px-5 py-3.5 text-sm font-medium border-b-2 transition-all duration-150 whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tab.label}
                  {tab.id === 'trazabilidad' && (
                    <span className="ml-1.5 text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full">NEW</span>
                  )}
                </button>
              ))}
            </div>

            <div className="p-5">
              {/* DESCRIPCION */}
              {activeTab === 'descripcion' && (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground leading-relaxed">{product.desc}</p>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: t('Sector', 'Sector'), value: product.sector },
                      { label: t('Origen', 'Origin'), value: product.origin },
                      { label: t('Capacidad mensual', 'Monthly capacity'), value: product.capacity },
                      { label: t('Tiempo de entrega', 'Lead time'), value: product.leadTime },
                      { label: t('MOQ', 'MOQ'), value: `${product.moq.toLocaleString()} ${product.unit}s` },
                      { label: t('Precio base', 'Base price'), value: product.price },
                    ].map((row, i) => (
                      <div key={i} className="bg-muted/50 rounded-xl p-3">
                        <p className="text-xs text-muted-foreground mb-0.5">{row.label}</p>
                        <p className="text-sm font-semibold text-foreground">{row.value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TRAZABILIDAD - Key Feature */}
              {activeTab === 'trazabilidad' && (
                <div>
                  <div className="flex items-center gap-2 mb-5 p-3 bg-green-50 rounded-xl border border-green-200">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-600 flex-none"><polyline points="20 6 9 17 4 12"/></svg>
                    <p className="text-sm text-green-800 font-medium">
                      {t('Cadena de trazabilidad completa verificada por OrigenIA', 'Complete traceability chain verified by OrigenIA')}
                    </p>
                  </div>

                  <div className="relative">
                    {/* Vertical line */}
                    <div className="absolute left-6 top-4 bottom-4 w-0.5 bg-border" />

                    <div className="space-y-4">
                      {product.traceabilityStages.map((stage, i) => (
                        <div key={i} className="flex gap-4 relative">
                          {/* Icon */}
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center text-xl flex-none z-10 border-2 ${
                            stage.verified ? 'bg-green-50 border-green-300' : 'bg-muted border-border'
                          }`}>
                            {stage.icon}
                          </div>
                          {/* Content */}
                          <div className={`flex-1 bg-muted/30 rounded-xl p-4 border ${stage.verified ? 'border-green-100' : 'border-border'}`}>
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <h4 className="text-sm font-semibold text-foreground">{stage.title}</h4>
                              <div className="flex items-center gap-2 flex-none">
                                <span className="text-xs text-muted-foreground">{stage.date}</span>
                                {stage.verified && (
                                  <span className="flex items-center gap-0.5 text-xs text-green-700 bg-green-100 px-1.5 py-0.5 rounded-full border border-green-200">
                                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                                    {t('Ver', 'View')}
                                  </span>
                                )}
                              </div>
                            </div>
                            <p className="text-xs text-muted-foreground leading-relaxed">{stage.desc}</p>
                            {stage.verified && (
                              <button
                                onClick={() => setCertModal(stage.title)}
                                className="mt-2 text-xs text-primary hover:underline font-medium flex items-center gap-1"
                              >
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                                {t('Ver Certificado', 'View Certificate')}
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* QR Section */}
                  <div className="mt-6 p-5 bg-muted/30 rounded-xl border border-border text-center">
                    <div className="relative inline-block mb-3">
                      <div className="w-28 h-28 mx-auto bg-card border-2 border-border rounded-xl flex items-center justify-center relative overflow-hidden">
                        <svg width="96" height="96" viewBox="0 0 100 100" className="text-foreground">
                          <rect x="10" y="10" width="30" height="30" fill="currentColor" rx="3"/>
                          <rect x="15" y="15" width="20" height="20" fill="white" rx="2"/>
                          <rect x="20" y="20" width="10" height="10" fill="currentColor" rx="1"/>
                          <rect x="60" y="10" width="30" height="30" fill="currentColor" rx="3"/>
                          <rect x="65" y="15" width="20" height="20" fill="white" rx="2"/>
                          <rect x="70" y="20" width="10" height="10" fill="currentColor" rx="1"/>
                          <rect x="10" y="60" width="30" height="30" fill="currentColor" rx="3"/>
                          <rect x="15" y="65" width="20" height="20" fill="white" rx="2"/>
                          <rect x="20" y="70" width="10" height="10" fill="currentColor" rx="1"/>
                          <rect x="45" y="10" width="5" height="5" fill="currentColor"/>
                          <rect x="53" y="10" width="5" height="5" fill="currentColor"/>
                          <rect x="45" y="18" width="5" height="5" fill="currentColor"/>
                          <rect x="45" y="45" width="5" height="5" fill="currentColor"/>
                          <rect x="53" y="45" width="5" height="5" fill="currentColor"/>
                          <rect x="61" y="45" width="5" height="5" fill="currentColor"/>
                          <rect x="45" y="53" width="5" height="5" fill="currentColor"/>
                          <rect x="53" y="53" width="5" height="5" fill="currentColor"/>
                          <rect x="61" y="61" width="5" height="5" fill="currentColor"/>
                          <rect x="69" y="53" width="5" height="5" fill="currentColor"/>
                          <rect x="77" y="45" width="5" height="5" fill="currentColor"/>
                          <rect x="85" y="53" width="5" height="5" fill="currentColor"/>
                          <rect x="69" y="69" width="5" height="5" fill="currentColor"/>
                          <rect x="77" y="69" width="5" height="5" fill="currentColor"/>
                          <rect x="85" y="77" width="5" height="5" fill="currentColor"/>
                          <rect x="45" y="69" width="5" height="5" fill="currentColor"/>
                          <rect x="53" y="77" width="5" height="5" fill="currentColor"/>
                          <rect x="45" y="85" width="5" height="5" fill="currentColor"/>
                          <rect x="53" y="85" width="5" height="5" fill="currentColor"/>
                        </svg>
                        <div className="absolute inset-0 border-2 border-primary rounded-xl animate-pulse opacity-40" />
                      </div>
                    </div>
                    <p className="text-sm font-medium text-foreground mb-1">{t('Escanea para verificar el origen', 'Scan to verify origin')}</p>
                    <p className="text-xs text-muted-foreground mb-3">{t('Válido en cualquier momento', 'Valid at any time')}</p>
                    <button
                      onClick={handleCopyLink}
                      className="inline-flex items-center gap-2 text-xs text-primary border border-primary/30 bg-primary/5 px-3 py-1.5 rounded-lg hover:bg-primary/10 transition-colors font-medium"
                    >
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                      {copied ? t('¡Copiado!', 'Copied!') : t('Compartir trazabilidad', 'Share traceability')}
                    </button>
                  </div>
                </div>
              )}

              {/* CERTIFICACIONES */}
              {activeTab === 'certificaciones' && (
                <div>
                  <p className="text-sm text-muted-foreground mb-5">
                    {t('Este producto cuenta con las siguientes certificaciones internacionales verificadas:', 'This product holds the following verified international certifications:')}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {product.certs.map((cert, i) => (
                      <div key={i} className="flex items-center gap-3 p-4 bg-muted/30 rounded-xl border border-border hover:border-primary/30 transition-colors group">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary font-bold text-sm flex-none">
                          {cert.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">{cert}</p>
                          <p className="text-xs text-muted-foreground">{t('Vigente', 'Active')} 2024</p>
                        </div>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-auto text-muted-foreground group-hover:text-primary transition-colors"><polyline points="20 6 9 17 4 12"/></svg>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* LOGISTICA */}
              {activeTab === 'logistica' && (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    {t('Opciones de envío disponibles desde puertos colombianos:', 'Available shipping options from Colombian ports:')}
                  </p>
                  {product.shipping.map((s, i) => (
                    <div key={i} className="p-4 bg-muted/30 rounded-xl border border-border">
                      <div className="flex items-start gap-3">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary flex-none mt-0.5"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>
                        <div>
                          <p className="text-sm font-semibold text-foreground">{s.port}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">{s.time}</p>
                          <span className="inline-block mt-1.5 text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full border border-primary/20">{s.incoterm}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                    <p className="text-sm text-blue-800">
                      <strong>{t('Nota:', 'Note:')}</strong> {t('Los tiempos de tránsito son estimados. El tiempo exacto depende del puerto de destino y condiciones del operador logístico.', 'Transit times are estimates. Exact time depends on destination port and logistics operator conditions.')}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column - Quote Request */}
        <div className="lg:col-span-1">
          <div className="bg-card rounded-2xl border border-border p-5 sticky top-6 space-y-5">

            {/* Producer card */}
            <div className="flex items-center gap-3 p-3.5 bg-muted/40 rounded-xl border border-border">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-sm flex-none">
                {product.producer.slice(0, 2).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{product.producer}</p>
                <div className="flex items-center gap-1">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-muted-foreground flex-none"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                  <p className="text-xs text-muted-foreground truncate">{product.origin}</p>
                </div>
              </div>
              <span className="text-[10px] bg-green-100 text-green-700 border border-green-200 px-2 py-0.5 rounded-full font-semibold flex-none">
                {t('Verificado', 'Verified')}
              </span>
            </div>

            <div>
              <h3 className="text-base font-semibold text-foreground mb-0.5">{t('Solicitar Cotización', 'Request Quote')}</h3>
              <p className="text-xs text-muted-foreground">{t('El productor responde en menos de 24h', 'Producer responds in under 24h')}</p>
            </div>

            <div className="space-y-4">
              {/* Price */}
              <div className="bg-primary/5 rounded-xl p-4 border border-primary/20">
                <p className="text-xs text-muted-foreground mb-0.5">{t('Precio referencial FOB', 'Reference FOB price')}</p>
                <p className="text-xl font-bold text-primary">{product.price}</p>
                <p className="text-xs text-muted-foreground mt-1">{t('Precio final sujeto a volumen y condiciones', 'Final price subject to volume and conditions')}</p>
              </div>

              {/* Quantity */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  {t('Cantidad solicitada', 'Requested quantity')}
                </label>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setQty(q => Math.max(product.moq, q - product.moq))}
                    className="w-9 h-9 border border-border rounded-lg flex items-center justify-center text-foreground hover:bg-muted transition-colors text-lg font-bold"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    value={qty}
                    onChange={e => setQty(Math.max(product.moq, Number(e.target.value)))}
                    className="flex-1 border border-border rounded-lg px-3 py-2 text-sm text-center bg-background text-foreground focus:outline-none focus:border-primary"
                  />
                  <button
                    onClick={() => setQty(q => q + product.moq)}
                    className="w-9 h-9 border border-border rounded-lg flex items-center justify-center text-foreground hover:bg-muted transition-colors text-lg font-bold"
                  >
                    +
                  </button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {t('Mínimo:', 'Minimum:')} {product.moq.toLocaleString()} {product.unit}s
                </p>
              </div>

              {/* Destination */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  {t('País de destino', 'Destination country')}
                </label>
                <select
                  value={destCountry}
                  onChange={e => setDestCountry(e.target.value)}
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary"
                >
                  {COUNTRIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>

              {/* Message */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  {t('Detalles adicionales para el productor', 'Additional details for producer')}
                </label>
                <textarea
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder={t('Especificaciones, empaque preferido, preguntas sobre certificaciones...', 'Specifications, preferred packaging, questions about certifications...')}
                  rows={3}
                  className="w-full border border-border rounded-lg px-3 py-2 text-sm bg-background text-foreground focus:outline-none focus:border-primary resize-none placeholder:text-muted-foreground"
                />
              </div>

              <button
                onClick={handleSubmitQuote}
                className="w-full py-3 bg-primary text-primary-foreground rounded-xl text-sm font-semibold hover:bg-primary/90 transition-all hover:shadow-lg hover:shadow-primary/20"
              >
                {t('Enviar Solicitud de Cotización', 'Send Quote Request')}
              </button>

              {showSuccess && (
                <div className="flex items-center gap-2 p-3.5 bg-green-50 border border-green-200 rounded-xl">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-600 flex-none"><polyline points="20 6 9 17 4 12"/></svg>
                  <p className="text-sm text-green-800 font-medium">{t('Solicitud enviada. Te contactaremos pronto.', 'Request sent. We will contact you soon.')}</p>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-border">
              <Link href="/buyer/messages" className="flex items-center justify-center gap-2 w-full py-2.5 border border-border rounded-xl text-sm text-foreground hover:bg-muted transition-colors">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                {t('Enviar mensaje al productor', 'Send message to producer')}
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Certificate Modal */}
      {certModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setCertModal(null)} />
          <div className="relative bg-card rounded-2xl border border-border p-6 max-w-md w-full">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-foreground">{t('Certificado de', 'Certificate of')} {certModal}</h3>
              <button onClick={() => setCertModal(null)} className="text-muted-foreground hover:text-foreground">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="bg-muted/30 rounded-xl p-6 text-center border border-border mb-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-primary"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="m9 15 2 2 4-4"/></svg>
              </div>
              <p className="text-sm font-semibold text-foreground mb-1">{product.name}</p>
              <p className="text-xs text-muted-foreground mb-2">{certModal} — {t('Verificado', 'Verified')} 2024</p>
              <p className="text-xs text-muted-foreground">{t('Emitido por OrigenIA · Blockchain verificado', 'Issued by OrigenIA · Blockchain verified')}</p>
            </div>
            <button className="w-full py-2.5 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors">
              {t('Descargar PDF', 'Download PDF')}
            </button>
          </div>
        </div>
      )}
    </BuyerLayout>
  )
}
